import mongoose from "mongoose";

const subRoleSchema = new mongoose.Schema({
    name: {
        type: String,
        enum: ["TL", "Manager", "GM"],
        ref: "SubRole",
        required: true,
    },
});

const roleSchema = new mongoose.Schema({
    roleName: { type: String, required: true, unique: true },
    subRole: mongoose.Schema.Types.ObjectId,
});

export const Role = mongoose.model("Role", roleSchema);
export const SubRole = mongoose.model("SubRole", subRoleSchema);
