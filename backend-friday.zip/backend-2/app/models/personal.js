import mongoose from "mongoose";

const personalSchema = new mongoose.Schema({
    employeeId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
        required: true,
        index: true,
    },
    profile: {
        address: { type: String, trim: true },
        salary: { type: Number },
        additionalPhoneNumber: { type: String, trim: true },
        dateOfBirth: { type: Date },
        profilePhoto: { type: Buffer, default: null },
        currentState: { type: String, trim: true },
        martialStatus: { type: String, enum: ["Married", "Single", "Widow", "Others"], trim: true }
    },
    academics: {
        sslc: {
            sslcPercentage: { type: Number },
            sslcSchool: { type: String, trim: true },
            sslcCertificate: { type: Buffer },
        },
        hse: {
            hsePercentage: { type: Number },
            hseSchool: { type: String, trim: true },
            hseCertificate: { type: Buffer },
        },
        graduation: {
            graduatePercentage: { type: Number },
            graduateCollegeName: { type: String, trim: true },
            graduateCollegeAddress: { type: String, trim: true },
            graduateYearOfPassedOut: { type: Number },
            graduateBacklogs: { type: Number },
            graduationCertificate: { type: Buffer, default: null }
        }
    },
    documents: {
        pan: {
            panNumber: { type: String },
            panProof: { type: Buffer, default: null }
        },
        aadhar: {
            aadharNumber: { type: String },
            aadharProof: { type: Buffer, default: null }
        },
        bank: {
            accNo: { type: String },
            passbook: { type: Buffer, default: null }
        }
    },

    experience: [
        {
            companyName: { type: String, trim: true },
            role: { type: String, trim: true },
            present: { type: Boolean },
            from: { type: Date },
            to: { type: Date }
        }
    ]
},
    {
        timestamps: true
    }
);

export const Personal = mongoose.model("Personal", personalSchema);
