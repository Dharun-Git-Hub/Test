import mongoose from "mongoose";

const leave = new mongoose.Schema({
    subject: { type: String, enum: ["PERMISSION","LEAVE","OTHERS"] },
    mailData: { type: String, required: true },
    date: [{ type: Date, required: true }],
    approved: Boolean,
    authorities: [String],
    signed: [String]
})

export const Leave = mongoose.model('Leave',leave)