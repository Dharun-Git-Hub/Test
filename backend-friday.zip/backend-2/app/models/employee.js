import mongoose from "mongoose";

const employeeSchema = new mongoose.Schema({
  firstName: { type: String, required: true, trim: true },
  lastName: { type: String, trim: true, default: "" },
  employeeId: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  employeeNumber: { type: Number, required: true },
  appPassword: { type: String, required: true },
  password: { type: String, required: true },
  phone: { type: String, required: true },

  department: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Role",
    required: true
  },

  specialRole: {
    type: mongoose.Schema.Types.ObjectId,
    default: null
  },

  dateOfJoining: { type: Date, default: Date.now },
  assignees: [{ type: mongoose.Schema.Types.ObjectId, ref: "Employee" }],
  leaves: [{ type: mongoose.Schema.Types.ObjectId, ref: "Leave" }],
  martialStatus: { type: String, enum: ["Married", "Widow", "Single", "Others"] },
  gender: { type: String, enum: ["Male", "Female", "Others"] },
  currentStatus: { type: String, enum: ["Probation", "Trainee", "Intern", "Junior", "Senior", "Professional"] }
});

export const Employee = mongoose.model("Employee", employeeSchema);
