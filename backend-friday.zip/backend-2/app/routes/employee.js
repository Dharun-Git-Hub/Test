import express from 'express'
import * as EmployeeControllers from '../controllers/employee.js'
import { authorizeRole } from '../middlewares/authorizeRole.js'
import { requireAuth } from '../middlewares/requireAuth.js'
import * as EmployeeValidators from '../validators/employeeValidator.js'

const router = express.Router()

router.post('/addEmployee', requireAuth, authorizeRole("Manager", "HR"), EmployeeValidators.addEmployeeValidator, EmployeeControllers.addEmployee)
router.post('/deleteEmployee', requireAuth, authorizeRole("Manager", "HR"), EmployeeValidators.deleteEmployeeValidator, EmployeeControllers.deleteEmployee)
router.post('/updateEmployee', requireAuth, authorizeRole("Manager", "HR"), EmployeeValidators.updateEmployeeValidator, EmployeeControllers.updateEmployee)
router.post('/getAllEmployees', requireAuth, authorizeRole("Manager", "HR"), EmployeeControllers.getAllEmployees)
router.post('/askForPermission', requireAuth, EmployeeValidators.askForPermissionValidator, EmployeeControllers.askForPermission)
router.post('/managersList', requireAuth, authorizeRole("Manager", "HR"), EmployeeControllers.managersList)
router.post('/tlsList', requireAuth, authorizeRole("Manager", "HR"), EmployeeControllers.tlsList)
router.post('/editPersonalDetails', requireAuth, authorizeRole("Employee", "HR", "Manager"), EmployeeValidators.editPersonalValidator, EmployeeControllers.editPersonalDetails)
router.post('/getMyDetails', requireAuth, EmployeeControllers.getMyDetails)
router.post('/getLeaveForms', requireAuth, authorizeRole("HR"), EmployeeControllers.getLeaveForms)
router.post('/getPendingRequests', requireAuth, authorizeRole("Manager", "TL", "HR"), EmployeeControllers.getPendingRequests)
router.post('/loginEmployee', EmployeeValidators.loginEmployeeValidator, EmployeeControllers.loginEmployee)
router.post('/requestChangePassword', EmployeeValidators.requestChangePasswordValidator, EmployeeControllers.requestChangePassword)
router.post('/changePassword', EmployeeValidators.changePasswordValidator, EmployeeControllers.changePassword)

export default router