import express from 'express'
import * as AdminControllers from '../controllers/admin/admin.js'
import { requireAuth } from '../middlewares/requireAuth.js'
import { authorizeRole } from '../middlewares/authorizeRole.js'
import * as EmployeeValidators from '../validators/employeeValidator.js'
import * as EmployeeControllers from '../controllers/employee.js'
import * as AdminValidators from '../validators/adminValidator.js'

const router = express.Router()

router.post('/addEmployee', requireAuth, authorizeRole("ADMIN"), EmployeeValidators.addEmployeeValidator, EmployeeControllers.addEmployee)
router.post('/deleteEmployee', requireAuth, authorizeRole("ADMIN"), EmployeeValidators.deleteEmployeeValidator, EmployeeControllers.deleteEmployee)
router.post('/updateEmployee', requireAuth, authorizeRole("ADMIN"), EmployeeValidators.updateEmployeeValidator, EmployeeControllers.updateEmployee)
router.post('/getAllEmployees', requireAuth, authorizeRole("ADMIN"), EmployeeControllers.getAllEmployees)
router.post('/managersList', requireAuth, authorizeRole("ADMIN"), EmployeeControllers.managersList)
router.post('/tlsList', requireAuth, authorizeRole("ADMIN"), EmployeeControllers.tlsList)
router.post('/editPersonalDetails', requireAuth, authorizeRole("ADMIN"), EmployeeValidators.editPersonalValidator, EmployeeControllers.editPersonalDetails)
router.post('/getLeaveForms', requireAuth, authorizeRole("ADMIN"), EmployeeControllers.getLeaveForms)
router.post('/loginAdmin', AdminValidators.loginAdminValidator, AdminControllers.loginAdmin)
router.post('/changePassword', EmployeeValidators.changePasswordAdValidator, AdminControllers.changePassword)

export default router