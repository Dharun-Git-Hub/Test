import express from 'express'
import * as DepartmentControllers from '../controllers/department.js'
import { requireAuth } from '../middlewares/requireAuth.js'
import { authorizeRole } from '../middlewares/authorizeRole.js'
import * as DepartmentValidators from '../validators/departmentValidator.js'

const router = express.Router()

router.post('/addDepartment', requireAuth, authorizeRole("Manager", "HR"), DepartmentValidators.createDepartmentValidator, DepartmentControllers.createDepartment)
router.post('/updateDepartment', requireAuth, authorizeRole("Manager", "HR"), DepartmentValidators.updateDepartmentValidator, DepartmentControllers.updateDepartment)
router.post('/deleteDepartment', requireAuth, authorizeRole("Manager", "HR"), DepartmentValidators.deleteDepartmentValidator, DepartmentControllers.deleteDepartment)
router.post('/getAllDepartments', requireAuth, authorizeRole("Manager", "HR"), DepartmentControllers.getAllDepartments)

export default router