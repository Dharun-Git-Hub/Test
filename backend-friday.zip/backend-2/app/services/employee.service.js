import { hrsId, managersId, tlsId } from "../helper/helper.js";
import { Employee } from "../models/employee.js";
import { Leave } from "../models/leave.js";
import { Personal } from '../models/personal.js'
import { Role, SubRole } from "../models/role.js";
import bcrypt from 'bcrypt'

export const createEmployee = async (details) => {
    try {
        details.password = await bcrypt.hash("000", 10)
        if ((await Employee.countDocuments()) === 0) {
            details.employeeId = "FC" + (0o0 + (1).toString().padStart(3, '0'));
            details.employeeNumber = 1
        }
        else {
            const lastNumber = await Employee.findOne().sort({ _id: -1 }).limit(1)
            console.log(lastNumber)
            details.employeeNumber = lastNumber.employeeNumber + 1;
            console.log("EMPLOYEE NUMBER : ", lastNumber.employeeNumber)
            details.employeeId = "FC" + (0o0 + (details.employeeNumber).toString().padStart(3, '0'));
        }
        const employee = await Employee.create(details);
        await Personal.create({ employeeId: employee._id });
        console.log('Personal Space Created!')
        return employee;
    } catch (err) {
        console.error("Error creating employee:", err);
        throw err;
    }
};

export const updateEmployeeById = async (id, updatedData) => {
    try {
        const employee = await Employee.findByIdAndUpdate(
            id,
            { $set: updatedData },
            { new: true, runValidators: true }
        );
        return employee;
    } catch (err) {
        console.error("Error in updateEmployeeById:", err);
        throw err;
    }
};

export const editEmployeePersonals = async (id, updatedData) => {
    try {
        console.log(updatedData)
        const found = await Personal.findOne({ employeeId: id })
        console.log(found)
        await Personal.findOneAndUpdate(
            { employeeId: id },
            { $set: updatedData },
            { new: true, runValidators: true }
        );
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const deleteEmployeeById = async (id) => {
    try {
        const deletedEmployee = await Employee.findByIdAndDelete(id);
        await Personal.deleteOne({ employeeId: id });
        return deletedEmployee;
    } catch (err) {
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
};

export const getAllEmployeesList = async (filter) => {
    try {
        const list = await Employee.find(filter)
        console.log(list)
        return list
    }
    catch (err) {
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
}

export const findEmployeeByIdAssignees = async (id) => {
    try {
        const details = await Employee.findById(id)
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeeIfExists = async (filter) => {
    try {
        const details = await Employee.findOne(filter)
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getManagersList = async () => {
    try {
        const manager = await managersId()
        const data = await Employee.find({ specialRole: manager }).populate("department").select("-password")
        console.log("Managers: ", data)
        if (data) {
            let temp = []
            for (const i of data) {
                let dtls = {
                    name: i.firstName + " " + i.lastName,
                    email: i.email,
                    department: i.department.roleName
                }
                temp.push(dtls)
            }
            return temp
        }
        return data
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getTlsList = async () => {
    try {
        const tl = await tlsId()
        const data = await Employee.find({ specialRole: tl }).populate("department").select("-password")
        console.log("TLs: ", data)
        if (data) {
            let temp = []
            for (const i of data) {
                let dtls = {
                    name: i.firstName + " " + i.lastName,
                    email: i.email,
                    department: i.department.roleName
                }
                temp.push(dtls)
            }
            return temp
        }
        return data
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeeById = async (id) => {
    try {
        const details = await Employee.findById(id)
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeeByIdDeployed = async (id) => {
    try {
        const details = await Employee.findById(id).populate('department').lean();
        if (!details) throw new Error("Employee not found");
        const specialRoleDtls = await SubRole.findById(details.specialRole).lean();
        const result = {
            ...details,
            specialRole: specialRoleDtls
        };
        return result;
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const getEmployeeByIdSecurely = async (id) => {
    try {
        const details = await Employee.findById(id).select("-password")
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeePersonals = async (id) => {
    try {
        const details = await Personal.findOne({ employeeId: id })
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getLeaveFormById = async (id) => {
    try {
        const form = await Leave.findById(id)
        return form
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getPendingForms = async (id, email) => {
    try {
        const form = await Leave.findOne({
            _id: id,
            authorities: { $in: [email] }
        });
        return form
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const findHrs = async () => {
    try {
        const hr = await hrsId()
        const list = await Employee.find({ department: hr })
        return list.map(e => e.email)
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const createLeaveForm = async (subject, reason, date, mails) => {
    try {
        const leaveForm = await Leave.create({
            subject,
            mailData: reason,
            date,
            approved: false,
            authorities: mails,
            signed: []
        })
        return leaveForm
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const updateEmployeeLeave = async (_id,leaveForm) => {
    try {
        await Employee.findByIdAndUpdate(
            _id,
            { $push: { leaves: leaveForm._id } },
            { new: true, useFindAndModify: false }
        );
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const findManagerId = async () => {
    const id = await SubRole.findOne({name:"Manager"})
    if(id)
        return id._id
    return id
}

export const findTlId = async () => {
    const id = await SubRole.findOne({name:"TL"})
    if(id)
        return id._id
    return id
}

export const findHrId = async () => {
    const id = await Role.findOne({roleName:"HR"})
    console.log(id)
    if(id)
        return id._id
    return id
}