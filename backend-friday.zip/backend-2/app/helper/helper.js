import { validationResult } from "express-validator";
import dotenv from 'dotenv'
import crypto from 'crypto-js'
import * as EmployeeServices from "../services/employee.service.js";

dotenv.config()

const aes_secret = process.env.AES_SECRET
const admin_secret = process.env.ADMIN_SECRET

export const removeExtensionFromFile = (file) => {
    return file.split('.').slice(0, -1).join('.').toString();
};

export const validateResult = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const firstError = errors.array()[0].msg;
        return res.status(200).json({ success: false, message: firstError });
    }
    if (req.body.email) {
        req.body.email = req.body.email.toLowerCase()
    }
    next();
};

export const encryptData = (data) => {
    const crypted = crypto.AES.encrypt(data, aes_secret).toString()
    return crypted
}

export const encryptAdmin = (data) => {
    const crypted = crypto.AES.encrypt(data,admin_secret).toString()
    return crypted
}

export const decryptData = (data) => {
    const decrypted = crypto.AES.decrypt(data, aes_secret)
    console.log(decrypted.toString(crypto.enc.Utf8))
    return decrypted.toString(crypto.enc.Utf8)
}

export const decryptAdmin = (data) => {
    const decrypted = crypto.AES.decrypt(data, admin_secret)
    return decrypted.toString(crypto.enc.Utf8)
}

export const createMail = (subject, date, reason, authority, specialRole = "", type = "PERMISSION",employeeId,myName,department) => {
    let finalSubject = "";
    let htmlBody = "";

    switch (type) {
        case "PERMISSION":
            finalSubject = `${subject} Request - Regarding`;
            htmlBody = `
                <h2>Dear ${authority},</h2>
                <p>I hope this message finds you well.</p>
                <p>I would like to request permission for the following reason:</p>
                <blockquote>${reason}</blockquote>
                <p>On ${date.map(e=>new Date(e).toLocaleString()).join(", ")}
                <p>Kindly let me know if this can be approved.</p>
                </br>
                <b>Thanks and Regards</b>
                <p>${myName}</p>
                <p>${employeeId}</p>
                <p>${specialRole}</p>
                <p>${department} Department</p>
                <p>Fourchain Technologies</p>
            `;
            break;

        case "LEAVE":
            finalSubject = `Leave Application: ${subject}`;
            htmlBody = `
                <h2>Dear ${specialRole},</h2>
                <p>I am writing to formally request leave for the following reason:</p>
                <blockquote>${reason}</blockquote>
                <p>On ${date.map(e=>new Date(e).toLocaleDateString()).join(", ")}
                <p>Please let me know if this leave can be approved.</p>
                </br>
                <b>Thanks and Regards</b>
                <p>${myName}</p>
                <p>${employeeId}</p>
                <p>${specialRole}</p>
                <p>${department} Department</p>
                <p>Fourchain Technologies</p>
            `;
            break;

        default:
            finalSubject = `Notification: ${subject}`;
            htmlBody = `
                <h2>Dear ${specialRole},</h2>
                <p>${reason}</p>
                <p>On ${date.map(e=>new Date(e).toLocaleDate()).join(", ")}
                <p>– The Team</p>
            `;
    }

    return { subject: finalSubject, htmlBody };
};

export const managersId = async () => { return await EmployeeServices.findManagerId() }
export const tlsId = async () => { return await EmployeeServices.findTlId() }
export const hrsId = async () => { await EmployeeServices.findHrId() }