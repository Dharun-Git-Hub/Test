import { check } from "express-validator"
import { validateResult } from "../helper/helper.js"

export const loginAdminValidator = [
    check('userName')
        .exists()
        .withMessage('USER NAME IS MISSING')
        .not()
        .isEmpty()
        .withMessage('USER NAME MISSING'),

    check('email')
        .exists()
        .withMessage('EMAIL IS MISSING')
        .not()
        .isEmpty()
        .withMessage('EMAIL MISSING'),

    check('password')
        .exists()
        .withMessage('PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('PASSWORD MISSING'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]