import { check } from 'express-validator'
import { validateResult } from '../helper/helper.js'

export const addEmployeeValidator = [

    check('firstName')
        .exists()
        .withMessage('FIRST NAME MISSING')
        .not()
        .isEmpty()
        .withMessage('please fill First name')
        .isLength({ min: 4 })
        .withMessage('First Name must be at least 4 chars long')
        .matches(/^[A-Za-z0-9\s-]{1,16}$/)
        .withMessage('First name invalid format'),

    check('email')
        .exists()
        .withMessage('EMAIL IS MISSING')
        .not()
        .isEmpty()
        .withMessage('EMAIL MISSING')
        ,

    check('phone')
        .exists()
        .withMessage('PHONE NUMBER IS MISSING')
        .not()
        .isEmpty()
        .withMessage('PHONE NUMBER MISSING')
        ,

    check('department')
        .exists()
        .withMessage('DEPARTMENT IS MISSING')
        .not()
        .isEmpty()
        .withMessage('DEPARTMENT MISSING')
        ,

    check("specialRole").custom((value, { req }) => {
        if (value === null) return true;
        if (typeof value === "undefined")
            throw new Error("SPECIAL ROLE MISSING");
        if (value === "") throw new Error("IS_EMPTY");
        return true;
    }),

    check('assignees')
        .exists()
        .withMessage('ASSIGNEES IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        ,

    check('appPassword')
        .exists()
        .withMessage('APP PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('APP PASSWORD IS MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const updateEmployeeValidator = [
    check('id')
        .exists()
        .withMessage('ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const deleteEmployeeValidator = [
    check('id')
        .exists()
        .withMessage('ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const loginEmployeeValidator = [

    check('email')
        .exists()
        .withMessage('EMAIL IS MISSING')
        .not()
        .isEmpty()
        .withMessage('EMAIL IS MISSING')
        ,

    check('password')
        .exists()
        .withMessage('PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('PASSWORD MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const requestChangePasswordValidator = [

    check('employeeId')
        .exists()
        .withMessage('ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID MISSING')
        ,
    
    check('email')
        .exists()
        .withMessage('EMAIL IS MISSING')
        .not()
        .isEmpty()
        .withMessage('EMAIL MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const changePasswordValidator = [

    check('id')
        .exists()
        .withMessage('NEW PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID IS MISSING')
        ,

    check('assignedPassword')
        .exists()
        .withMessage('ASSIGNED PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ASSIGNED PASSWORD IS MISSING')
        ,

    check('newPassword')
        .exists()
        .withMessage('NEW PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('NEW PASSWORD IS MISSING')
        ,
    
    check('repeatPassword')
        .exists()
        .withMessage('REPEATED PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('REPEATED PASSWORD IS MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const changePasswordAdValidator = [

    check('id')
        .exists()
        .withMessage('NEW PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID IS MISSING')
        ,

    check('newPassword')
        .exists()
        .withMessage('NEW PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('NEW PASSWORD IS MISSING')
        ,
    
    check('repeatPassword')
        .exists()
        .withMessage('REPEATED PASSWORD IS MISSING')
        .not()
        .isEmpty()
        .withMessage('REPEATED PASSWORD IS MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]


export const editPersonalValidator = [

    check('id')
        .exists()
        .withMessage('ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID MISSING')
        ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const askForPermissionValidator = [

    check('subject')
        .exists()
        .withMessage('SUBJECT IS MISSING')
        .not()
        .isEmpty()
        .withMessage('SUBJECT IS MISSING'),

    check('reason')
        .exists()
        .withMessage('REASON IS MISSING')
        .not()
        .isEmpty()
        .withMessage('REASON IS MISSING'),

    check('date')
        .exists()
        .withMessage('PERMISSION DATE IS MISSING')
        .not()
        .isEmpty()
        .withMessage('PERMISSION DATE IS MISSING'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]