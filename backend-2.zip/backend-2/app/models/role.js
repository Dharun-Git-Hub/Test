import mongoose from "mongoose";

const role = new mongoose.Schema({
    roleName: { type: String, enum: ["HR","Development","UI/UX","Marketing"], required: true },
    subRole: [{
        type: String,
        enum: ["TL","Manager","GM"]
    }]
})

export const Role = mongoose.model('Role',role)