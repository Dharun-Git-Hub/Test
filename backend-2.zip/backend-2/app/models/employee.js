import mongoose from "mongoose";

const employeeSchema = new mongoose.Schema({
    firstName: { type: String, required: true, trim: true },
    lastName: { type: String, trim: true, default: "" },
    employeeId: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    phone: { type: String, required: true },
    department: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
    },
    specialRole: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Role.subRole",
        default: null,
    },
    dateOfJoining: { type: Date, default: Date.now },
    assignees: [mongoose.Schema.Types.ObjectId]
});

export const Employee = mongoose.model("Employee", employeeSchema)