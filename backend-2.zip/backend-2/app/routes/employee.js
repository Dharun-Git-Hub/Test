import express from 'express'
import * as EmployeeControllers from '../controllers/employee'

const router = express.Router()

router.post('/addEmployee',EmployeeControllers.addEmployee)

export default router