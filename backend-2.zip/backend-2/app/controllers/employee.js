export const addEmployee = async (req,res) => {
    try{
        const {firstName,lastName,employeeId,email,password,phone,department,specialRole} = req.body
        
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}