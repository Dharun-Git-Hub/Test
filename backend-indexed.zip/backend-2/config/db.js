import mongoose from 'mongoose';
import dotenv from 'dotenv'
import * as DepartmentService from '../app/services/department.service.js';

dotenv.config()

export const connectToDatabase = async () => {
    const MONGO_URI = process.env.MONGO_URI
    try {
        await mongoose.connect(MONGO_URI);
        console.log('MongoDB Connected!');
        await DepartmentService.addDepartments(["HR", "UI/UX", "FullStack", "Marketing"])
        await DepartmentService.loadSubRoles(["TL", "Manager", "GM"])
        await DepartmentService.initializeCounter()
    }
    catch (err) {
        console.error('Error connecting to the database', err);
        process.exit(1);
    }
};
