import express from 'express'
import cors from 'cors'
import router from './app/routes/index.js'
import { connectToDatabase } from './config/db.js'

const app = express()
const PORT = 3000

app.use(express.json())
app.use(cors())
app.use(router)

const startServer = async () => {
    try {
        await connectToDatabase()
        app.listen(PORT, () => {
            console.log(`Server Initiated @Port: ${PORT}`)
        })
    }
    catch (err) {
        console.log(err)
    }
}

startServer()

