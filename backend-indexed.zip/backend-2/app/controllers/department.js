import * as DepartmentServices from "../services/department.service.js";

export const createDepartment = async (req, res) => {
    try {
        const { roleName } = req.body;
        const newRole = await DepartmentServices.createNewDepartment(roleName)
        if (!newRole)
            res.status(200).json({ success: false, message: "Department Not Created!", result: [] })
        res.status(200).json({
            success: true,
            message: "Department created successfully",
            department: newRole,
            result: []
        });
    } catch (error) {
        console.error("Error creating department:", error);
        res.status(200).json({ success: false, message: "Server error", error: error.message, result: [] });
    }
};

export const updateDepartment = async (req, res) => {
    try {
        const { id, roleName } = req.body;

        if (!roleName) {
            return res.status(200).json({ success: false, message: "roleName is required", result: [] });
        }

        const updatedRole = await DepartmentServices.updateDepartmentById(id, roleName)

        if (!updatedRole) {
            return res.status(200).json({ success: false, message: "Department not found", result: [] });
        }

        res.status(200).json({
            success: true,
            message: "Department updated successfully",
            department: updatedRole,
            result: []
        });
    } catch (error) {
        console.error("Error updating department:", error);
        res.status(200).json({ success: false, message: "Server error", error: error.message, result: [] });
    }
};

export const deleteDepartment = async (req, res) => {
    try {
        const { id } = req.body;

        const deletedRole = await DepartmentServices.deleteDepartmentById(id)

        if (!deletedRole) {
            return res.status(200).json({ success: false, message: "Department not found", result: [] });
        }

        res.status(200).json({
            success: true,
            message: "Department deleted successfully",
            department: deletedRole,
            result: []
        });
    } catch (error) {
        console.error("Error deleting department:", error);
        res.status(200).json({ success: false, message: "Server error", error: error.message, result: [] });
    }
};

export const getAllDepartments = async (req, res) => {
    try {
        const list = await DepartmentServices.readAllDepartments()
        return res.status(200).json({ success: true, message: "Departments List Prepared!", departments: list, result: [] })
    }
    catch (err) {
        console.log(err)
        res.status(200).json({ success: false, message: "Server error", error: err.message, result: [] });
    }
}