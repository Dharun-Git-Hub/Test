import { Employee } from "../models/employee.js";
import { Leave } from "../models/leave.js";
import { Personal } from "../models/personal.js";
import { getCurrentId, incrementCurrent } from "./department.service.js";
import bcrypt from "bcrypt";

export const createEmployee = async (details) => {
    try {
        details.password = await bcrypt.hash("000", 10);
        details.employeeId =
            "FC" + (0o0 + (await getCurrentId())).toString().padStart(4, "0");
        const employee = await Employee.create(details);
        await Personal.create({ employeeId: employee._id });
        await incrementCurrent();
        return employee;
    } catch (err) {
        console.error("Error creating employee:", err);
        throw err;
    }
};

export const updateEmployeeById = async (id, updatedData) => {
    try {
        const employee = await Employee.findByIdAndUpdate(
            id,
            { $set: updatedData },
            { new: true, runValidators: true }
        );
        return employee;
    } catch (err) {
        console.error("Error in updateEmployeeById:", err);
        throw err;
    }
};

export const editEmployeePersonals = async (id, updatedData) => {
    try {
        console.log(updatedData);
        // Removed redundant findOne query and using the index on employeeId directly
        await Personal.findOneAndUpdate(
            { employeeId: id },
            { $set: updatedData },
            { new: true, runValidators: true }
        );
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const deleteEmployeeById = async (id) => {
    try {
        const deletedEmployee = await Employee.findByIdAndDelete(id);
        await Personal.findOneAndDelete({ employeeId: id });
        return deletedEmployee;
    } catch (err) {
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
};

export const getAllEmployeesList = async (filter) => {
    try {
        const list = await Employee.find(filter);
        return list;
    } catch (err) {
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
};

export const findEmployeeByIdAssignees = async (id) => {
    try {
        const details = await Employee.findById(id);
        return details;
    } catch (err) {
        console.log(err);
        throw err;
    }
};

export const getEmployeeIfExists = async (filter) => {
    try {
        const details = await Employee.findOne(filter);
        return details;
    } catch (err) {
        console.log(err);
        throw err;
    }
};

export const getManagersList = async () => {
    try {
        // Using lean() for better performance since we don't need Mongoose document methods
        const data = await Employee.find({
            specialRole: "68f9d7b038be33106b1f8845",
        })
            .populate("department")
            .select("firstName lastName email department") // Only select fields we need
            .lean(); // Convert to plain JS object for better performance
        console.log("Managers: ", data);
        if (data) {
            return data.map((i) => ({
                name: `${i.firstName} ${i.lastName}`,
                email: i.email,
                department: i.department.roleName,
            }));
        }
        return data;
    } catch (err) {
        console.log(err);
        throw err;
    }
};

export const getTlsList = async () => {
    try {
        // Using lean() for better performance since we don't need Mongoose document methods
        const data = await Employee.find({
            specialRole: "68f9d7b038be33106b1f8842",
        })
            .populate("department")
            .select("firstName lastName email department") // Only select fields we need
            .lean(); // Convert to plain JS object for better performance
        console.log("TLs: ", data);
        if (data) {
            return data.map((i) => ({
                name: `${i.firstName} ${i.lastName}`,
                email: i.email,
                department: i.department.roleName,
            }));
        }
        return data;
    } catch (err) {
        console.log(err);
        throw err;
    }
};

export const getEmployeeById = async (id) => {
    try {
        const details = await Employee.findById(id);
        console.log(id);
        return details;
    } catch (err) {
        console.log(err);
        throw err;
    }
};

export const getEmployeeByIdSecurely = async (id) => {
    try {
        const details = await Employee.findById(id).select("-password");
        return details;
    } catch (err) {
        console.log(err);
        throw err;
    }
};

export const getEmployeePersonals = async (id) => {
    try {
        const details = await Personal.findOne({ employeeId: id });
        return details;
    } catch (err) {
        console.log(err);
        throw err;
    }
};

export const getLeaveFormById = async (id) => {
    try {
        const form = await Leave.findById(id);
        return form;
    } catch (err) {
        console.log(err);
        throw err;
    }
};
