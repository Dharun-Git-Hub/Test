import jwt from "jsonwebtoken";
import { Employee } from "../models/employee.js";
import { SubRole } from "../models/role.js";

export const requireAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return res.status(401).json({ message: "No token provided" });
        }

        const token = authHeader.split(" ")[1];
        const decoded = jwt.verify(token, "JWT_SECRET");

        let employee = await Employee.findById(decoded.id).populate("department");

        if (!employee) {
            return res.status(200).json({ success: false, message: "User not found", result: [] });
        }

        if (employee.specialRole) {
            let specialRoleDetails = await SubRole.findById(employee.specialRole);
            let employeeObj = employee.toObject();
            employeeObj.specialRole = specialRoleDetails
            req.user = employeeObj;
        } else {
            req.user = employee;
        }
        console.log("Require Auth: ", req.user)
        next();

    } catch (error) {
        console.log(error)
        res.status(200).json({ success: false, message: "Invalid or expired token", result: [] });
    }
};
