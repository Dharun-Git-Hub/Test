export const authorizeRole = (...allowedRoles) => {
  return (req, res, next) => {
    const roleName = req.user?.department?.roleName;
    const subRoleName = req.user?.specialRole?.name || "Employee"
    console.log(roleName)
    console.log(subRoleName)

    if (
      !allowedRoles.includes(roleName) &&
      !allowedRoles.includes(subRoleName)
    ) {
      return res.status(200).json({
        success: false,
        message: "Forbidden. You do not have the required role.",
        result: [],
      });
    }

    next();
  };
};
