import { check } from 'express-validator'
import { validateResult } from '../helper/helper.js'

export const createDepartmentValidator = [

    check('roleName')
        .exists()
        .withMessage('DEPARTMENT NAME IS MISSING')
        .not()
        .isEmpty()
        .withMessage('DEPARTMENT NAME MISSING')
    ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const updateDepartmentValidator = [
    
    check('id')
        .exists()
        .withMessage('ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID IS MISSING'),

    check('roleName')
        .exists()
        .withMessage('DEPARTMENT NAME IS MISSING')
        .not()
        .isEmpty()
        .withMessage('DEPARTMENT NAME MISSING'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const deleteDepartmentValidator = [
    check('id')
        .exists()
        .withMessage('ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('ID IS MISSING')
    ,

    (req, res, next) => {
        validateResult(req, res, next)
    }
]