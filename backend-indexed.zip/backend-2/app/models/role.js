import mongoose from "mongoose";

const subRoleSchema = new mongoose.Schema({
    name: {
        type: String,
        enum: ["TL", "Manager", "GM"],
        ref: "SubRole",
        required: true,
        index: true,
    },
});

const roleSchema = new mongoose.Schema({
    roleName: { type: String, required: true, unique: true, index: true },
    subRole: { type: mongoose.Schema.Types.ObjectId, index: true },
});

export const Role = mongoose.model("Role", roleSchema);
export const SubRole = mongoose.model("SubRole", subRoleSchema);
