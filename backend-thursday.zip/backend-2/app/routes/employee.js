import express from 'express'
import * as EmployeeControllers from '../controllers/employee.js'
import { authorizeRole } from '../middlewares/authorizeRole.js'
import { requireAuth } from '../middlewares/requireAuth.js'
import * as EmployeeValidators from '../validators/employeeValidator.js'

const router = express.Router()

router.post('/addEmployee', requireAuth, authorizeRole("Manager", "HR"), EmployeeValidators.addEmployeeValidator, EmployeeControllers.addEmployee)
router.delete('/deleteEmployee', requireAuth, authorizeRole("Manager", "HR"), EmployeeValidators.deleteEmployeeValidator, EmployeeControllers.deleteEmployee)
router.patch('/updateEmployee', requireAuth, authorizeRole("Manager", "HR"), EmployeeValidators.updateEmployeeValidator, EmployeeControllers.updateEmployee)
router.get('/getAllEmployees', requireAuth, authorizeRole("Manager", "HR"), EmployeeControllers.getAllEmployees)
router.post('/loginEmployee', EmployeeValidators.loginEmployeeValidator, EmployeeControllers.loginEmployee)
router.post('/askFor', requireAuth, authorizeRole("Employee", "TL"), EmployeeControllers.askFor)
router.get('/managersList', requireAuth, authorizeRole("Manager", "HR"), EmployeeControllers.managersList)
router.get('/tlsList', requireAuth, authorizeRole("Manager", "HR"), EmployeeControllers.tlsList)
router.post('/requestChangePassword', EmployeeValidators.requestChangePasswordValidator, EmployeeControllers.requestChangePassword)
router.post('/changePassword', EmployeeValidators.changePasswordValidator, EmployeeControllers.changePassword)
router.patch('/editPersonalDetails', requireAuth, authorizeRole("Employee", "HR"), EmployeeValidators.editPersonalValidator, EmployeeControllers.editPersonalDetails)
router.get('/getMyDetails', requireAuth, EmployeeControllers.getMyDetails)
router.get('/getLeaveForms', requireAuth, authorizeRole("HR"), EmployeeControllers.getLeaveForms)

export default router