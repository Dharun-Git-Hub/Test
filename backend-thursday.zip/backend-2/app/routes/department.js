import express from 'express'
import * as DepartmentControllers from '../controllers/department.js'
import { requireAuth } from '../middlewares/requireAuth.js'
import { authorizeRole } from '../middlewares/authorizeRole.js'
import * as DepartmentValidators from '../validators/departmentValidator.js'

const router = express.Router()

router.post('/addDepartment', requireAuth, authorizeRole("Manager", "HR"), DepartmentValidators.createDepartmentValidator, DepartmentControllers.createDepartment)
router.patch('/updateDepartment', requireAuth, authorizeRole("Manager", "HR"), DepartmentValidators.updateDepartmentValidator, DepartmentControllers.updateDepartment)
router.delete('/deleteDepartment', requireAuth, authorizeRole("Manager", "HR"), DepartmentValidators.deleteDepartmentValidator, DepartmentControllers.deleteDepartment)
router.get('/getAllDepartments', requireAuth, authorizeRole("Manager", "HR"), DepartmentControllers.getAllDepartments)

export default router