import { Role, SubRole } from "../models/role.js";
import { Counter } from '../models/counter.js'

export const addDepartments = async (departments) => {
  try {
    if (!Array.isArray(departments) || departments.length === 0) {
      throw new Error("Departments must be a non-empty array");
    }

    const insertedOrUpdated = [];

    for (const roleName of departments) {
      const result = await Role.updateOne(
        { roleName },
        { $setOnInsert: { roleName, subRoles: [] } },
        { upsert: true }
      );

      insertedOrUpdated.push({ roleName, result });
    }

    return insertedOrUpdated;
  } catch (err) {
    console.error("Error adding departments:", err);
    throw err;
  }
};

export const loadSubRoles = async (subRoles) => {
  try {
    if (!Array.isArray(subRoles) || subRoles.length === 0) {
      throw new Error("subRoles must be a non-empty array");
    }

    const insertedOrUpdated = [];

    for (const name of subRoles) {
      const result = await SubRole.updateOne(
        { name },
        { $setOnInsert: { name } },
        { upsert: true }
      );

      insertedOrUpdated.push({ name, result });
    }

    return insertedOrUpdated;
  } catch (err) {
    console.error("Error adding departments:", err);
    throw err;
  }
}

export const initializeCounter = async () => {
  try {
    const exists = await Counter.findOne({})
    if (!exists)
      await Counter.create({ current: 1 })
  }
  catch (err) {
    console.log(err)
    throw err
  }
}

export const getCurrentId = async () => {
  try {
    const currentOne = await Counter.findOne({})
    return currentOne.current
  }
  catch (err) {
    console.log(err)
    throw err
  }
}

export const incrementCurrent = async () => {
  try {
    const current = await Counter.findOne({})
    let newCurrent = current.current + 1
    current.current = newCurrent
    await current.save()
  }
  catch (err) {
    console.log(err)
    throw err
  }
}

export const createNewDepartment = async (roleName) => {
  try {
    const newRole = await Role.create({
      roleName
    });
    return newRole
  }
  catch (err) {
    console.log(err)
    throw err
  }
}

export const updateDepartmentById = async (id, roleName) => {
  try {
    const updatedRole = await Role.findByIdAndUpdate(
      id,
      { roleName },
      { new: true, runValidators: true }
    );
    return updatedRole
  }
  catch (err) {
    console.log(err)
    throw err
  }
}

export const deleteDepartmentById = async (id) => {
  try {
    const deleted = await Role.findByIdAndDelete(id);
    return deleted
  }
  catch (err) {
    console.log(err)
    throw err
  }
}

export const readAllDepartments = async () => {
  try {
    const list = await Role.find({})
    return list
  }
  catch (err) {
    console.log(err)
    throw err
  }
}

export const getRoleNameById = async (id) => {
  try {
    console.log("ID: " + id)
    const details = await Role.findById(id)
    console.log(details)
    return details
  }
  catch (err) {
    console.log(err)
    throw err
  }
}