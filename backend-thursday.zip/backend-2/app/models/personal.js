import mongoose from "mongoose";

const personalSchema = new mongoose.Schema({
    employeeId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
        required: true,
    },
    address: { type: String },
    bankAccountNumber: { type: String },
    salary: { type: Number },
    additionalPhoneNumber: { type: String },

    sslcPercentage: { type: Number },
    sslcSchool: { type: String },
    sslcCertificate: { type: Buffer },

    hsePercentage: { type: Number },
    hseSchool: { type: String },
    hseCertificate: { type: Buffer },

    graduatePercentage: { type: Number },
    graduateCollegeName: { type: String },
    graduateCollegeAddress: { type: String },
    graduateYearOfPassedOut: { type: Number },
    graduateBacklogs: { type: Number },

    dateOfBirth: { type: Date },

    profilePhoto: { type: Buffer },

    postings: [{ type: String }],

    experience: [
        {
            companyName: { type: String },
            role: { type: String },
            present: { type: Boolean },
            from: { type: Date },
            to: { type: Date }
        }
    ]
}, { timestamps: true });

export const Personal = mongoose.model("Personal", personalSchema);
