import mongoose from 'mongoose'

const counterSchema = new mongoose.Schema({
    current: { type: Number, required: true }
})

export const Counter = mongoose.model('Counter', counterSchema)