import mongoose from "mongoose";

const leave = new mongoose.Schema({
    reason: { type: String, required: true },
    date: [{ type: Date, required: true }],
    approved: Boolean,
    authorities: [String],
    signed: [String]
})

export const Leave = mongoose.model('Leave',leave)