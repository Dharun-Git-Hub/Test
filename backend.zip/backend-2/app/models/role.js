import mongoose from "mongoose";

const roleSchema = new mongoose.Schema({
  roleName: {
    type: String,
    enum: ["Management", "Leader", "Employee"],
    required: true,
    unique: true
  },
  permissions: {
    create: { type: Boolean, default: false },
    read: { type: Boolean, default: false },
    update: { type: Boolean, default: false },
    delete: { type: Boolean, default: false },
  }
});

export const Role = mongoose.model("Role", roleSchema);