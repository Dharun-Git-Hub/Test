import { Role } from "../models/role.js";

export const seedRolesAndMappings = async () => {
    try {
        console.log("🌱 Starting role and mapping seeding...");
        const rolesData = [
            {
                roleName: "Management",
                permissions: { create: true, read: true, update: true, delete: true },
            },
            {
                roleName: "Leader",
                permissions: { create: false, read: true, update: true, delete: false },
            },
            {
                roleName: "Employee",
                permissions: { create: false, read: true, update: false, delete: false },
            },
            {
                roleName: "HR",
                permissions: { create: true, read: true, update: true, delete: true },
            }
        ];

        const roleDocs = {};
        for (const role of rolesData) {
            const doc = await Role.findOneAndUpdate(
                { roleName: role.roleName },
                role,
                { new: true, upsert: true }
            );
            roleDocs[role.roleName] = doc;
        }
    } catch (err) {
        console.log(err);
    }
};
