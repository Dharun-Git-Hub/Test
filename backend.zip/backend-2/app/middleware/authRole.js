import jwt from "jsonwebtoken";
import * as EmployeeRepo from "../repository/employee.js";
import { Role } from "../models/role.js";

const jwt_secret = "jwt_secret";

export const authRole = (action) => {
    return async (req, res, next) => {
        try {
            console.log(req.user);
            const user = req.user;
            console.log("Authenticated user:", user);

            const details = await EmployeeRepo.getIfExists({ _id: user.myId });
            if (!details) {
                return res.status(404).json({
                    success: false,
                    message: "Tampered Credentials!",
                    result: [],
                });
            }
            if (
                details.role.toString() !== user.myRole ||
                details.department !== user.department
            ) {
                return res.status(403).json({
                    success: false,
                    message: "Your credentials are tampered!",
                    result: [],
                });
            }

            const role = await Role.findById(details.role);
            console.log("ROLE: ", details);
            if (!role) {
                return res.status(403).json({
                    success: false,
                    message: "Role not found",
                    result: [],
                });
            }

            if (!role.permissions[action]) {
                return res.status(403).json({
                    success: false,
                    message: `You are not authorized to ${action}!`,
                    result: [],
                });
            }
            next();
        } catch (err) {
            console.error("AuthRole error:", err);
            return res.status(500).json({
                success: false,
                message: "Internal server error",
                result: [],
            });
        }
    };
};

export const verifyJWT = async (req, res, next) => {
    try {
        const token = req.headers["token"];
        console.log(token);
        if (!token)
            return res
                .status(200)
                .json({ success: false, message: "No token" });
        const decoded = jwt.decode(token);
        const verified = Date.now() < new Date(decoded.exp * 1000);
        if (!verified)
            return res.status(200).json({
                success: false,
                message: "TOKEN EXPIRED!",
                result: { move: "login" },
            });
        jwt.verify(token, jwt_secret, (err, user) => {
            if (err)
                return res.status(403).json({
                    message: "INVALID TOKEN",
                    result: { move: "login" },
                });
            console.log(user);
            req.user = user;
            console.log("Passed JWT Check");
            next();
        });
    } catch (err) {
        console.log(err);
        return res
            .status(200)
            .json({ success: false, message: "Invalid JWT Token", result: [] });
    }
};
