import { Employee } from "../models/employee.js";
import bcrypt from "bcrypt";
import { Role } from "../models/role.js";
import { leaderRoles, managementRoles } from "../helper/helper.js";

export const employeeExists = async (filter) => {
    const exists = await Employee.exists(filter);
    if (!exists) return false;
    return true;
};

export const createEmployee = async (details) => {
    await Employee.create(details);
};

export const removeEmployee = async (employeeId) => {
    await Employee.deleteOne(employeeId);
};

export const getIfExists = async (employeeId) => {
    const exists = await Employee.findOne(employeeId);
    if (exists) return exists;
    return null;
};

export const getAllIfExists = async (employeeId) => {
    const exists = await Employee.find(employeeId)
    if (exists) return exists;
    return null
}

export const comparePassword = async (employeeId, password) => {
    const details = await getIfExists({ employeeId });
    const matches = await bcrypt.compare(password, details.password);
    return matches;
};

export const modifyPassword = async (employeeId, newPassword) => {
    const hashed = await bcrypt.hash(newPassword, 10);
    await Employee.updateOne(
        {
            employeeId,
        },
        {
            password: hashed,
        }
    );
};

export const modifyEmployee = async (employeeId,details) => {
    await Employee.updateOne(
        { employeeId },
        { $set: { ...details } }
    );
};

export const getRoleForEmployee = async (department, specialRole) => {
    let role = await Role.findOne({ roleName: department });
    if (role) return role;
    if (managementRoles.includes(specialRole)) {
        role = await Role.findOne({ roleName: "Management" });
    } else if (leaderRoles.includes(specialRole)) {
        role = await Role.findOne({ roleName: "Leader" });
    }
    if (!role) {
        role = await Role.findOne({ roleName: "Employee" });
    }
    return role;
};
