import { Role } from "../models/role.js"

export const getRoleById = async (id) => {
    const details = await Role.findById(id)
    return details
}