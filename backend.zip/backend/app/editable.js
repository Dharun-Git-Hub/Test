export const mapped = new Map([
    ["Administration", ['Admin']],
    ["Management", ['HR','Manager']],
    ["Lead", ['TL']]
]);

export const approvalAuthorities = [
    'Manager',
    'TL',
    'None'
]