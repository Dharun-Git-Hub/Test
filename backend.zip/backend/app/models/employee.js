import mongoose from "mongoose";

const employee = new mongoose.Schema({
    employeeId: { type: String, required: true },
    employeeEmail: { type: String, required: true },
    firstName: { type: String, required: true },
    lastName: { type: String, default: '' },
    password: { type: String, required: true },
    department: { type: String, enum: ['HR', 'UI/UX', 'Frontend', 'Backend', 'FullStack'] },
    role: { type: String, enum: ['Intern', 'Junior', 'Senior', 'Professional'] },
    over: [String],
    specialRole: { type: String, enum: ['TL', 'Manager', 'ActiveTL', 'None'] }
})

export const Employee = mongoose.model('Employee', employee)