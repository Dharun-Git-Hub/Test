import mongoose from "mongoose";

const department = new mongoose.Schema({
    departmentName: { type: String, required: true },
    employees: [String]
})

export const Department = mongoose.model('Department', department)