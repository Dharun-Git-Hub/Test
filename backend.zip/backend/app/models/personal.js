import mongoose from "mongoose";

const personal = new mongoose.Schema({
    employeeId: { type: String, required: true },
    salary: { type: Number, required: true },
    loss: { type: Number, default: 0 },
    awards: [{
        title: { type: String, required: true },
        pic: Buffer,
    }]
})

export const Personal = mongoose.model('Personal', personal)