import mongoose from "mongoose";

const roles = new mongoose.Schema({
    role: {
        type: String, required: true
    }
})

export const Role = mongoose.model('Role',roles)