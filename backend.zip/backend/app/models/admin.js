import mongoose from 'mongoose'

const admin = new mongoose.Schema({
    employeeEmail: { type: String, required: true },
    password: { type: String, required: true }
})

export const Admin = mongoose.model('Admin', admin)