import mongoose from "mongoose";

const specialRoles = new mongoose.Schema({
    role: {
        type: String, required: true
    }
})

export const SpecialRole = mongoose.model('SpecialRole',specialRoles)