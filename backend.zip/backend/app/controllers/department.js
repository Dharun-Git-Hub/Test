import * as DepartmentRepo from "../repository/department.js"

export const getDepartment = async (req, res) => { // O(n)
    try {
        const { departmentName } = req.body
        const exists = await DepartmentRepo.isDepartmentExists(departmentName) //O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: 'Department Not Found!', result: [] })
        const departmentDetails = await DepartmentRepo.getDepartmentDetails(departmentName) // O(n)
        return res.status(200).json({ success: true, result: departmentDetails })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: 'Something went wrong!' })
    }
}

export const addNewDepartment = async (req, res) => { // O(n)
    try {
        const { departmentName } = req.body
        const exists = await DepartmentRepo.isDepartmentExists(departmentName) // O(n)
        if (exists)
            return res.status(200).json({ success: false, message: "Department already found!", result: [] })
        await DepartmentRepo.addDepartment(departmentName) // O(1)
        return res.status(200).json({ success: true, message: "New Department Created Successfully!" })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!" })
    }
}

export const deleteExistingDepartment = async (req, res) => { // O(n)
    try {
        const { departmentName } = req.body
        const exists = await DepartmentRepo.isDepartmentExists(departmentName) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: "Department Not Found!" })
        await DepartmentRepo.deleteDepartment(departmentName) // O(1)
        return res.status(200).json({ success: true, message: "Department Deleted Successfully!" })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!" })
    }
}

export const updateDepartment = async (req, res) => { // O(n)

    try {
        const { departmentName, newName } = req.body
        const exists = await DepartmentRepo.isDepartmentExists(departmentName) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: "Department Not Found!" })
        const existsNew = await DepartmentRepo.isDepartmentExists(newName) // O(n)
        if (existsNew)
            return res.status(200).json({ success: false, message: `Department ${newName} already found!` })
        await DepartmentRepo.updateDepartmentName(departmentName, newName); // O(log n) or O(n)
        return res.status(200).json({ success: true, message: "Department Renamed Successfully!" })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong" })
    }
}
