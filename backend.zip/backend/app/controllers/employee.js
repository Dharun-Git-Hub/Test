import * as EmployeeRepo from "../repository/employee.js"
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { getDepartments, getRoles, getSpecialRoles } from "../repository/department.js"
import { approvalAuthorities, mapped } from "../editable.js"
import { decryptData, encryptData } from "../helper.js"
import dotenv from 'dotenv'

dotenv.config()

const secret_key = process.env.SECRET

export const sayHello = async (req, res) => {
    return res.status(200).json({ success: true, message: "Hello, Employee!" })
}

export const addEmployee = async (req, res) => { // O(n)
    try {
        const { employeeId, employeeEmail, firstName, lastName, department, role, specialRole, password } = req.body
        const exists = await EmployeeRepo.employeeExists({ employeeId }) // O(n)
        if (exists)
            return res.status(200).json({ success: false, message: "Employee with this ID Already Found!" })
        const emailExist = await EmployeeRepo.emailExists({ employeeEmail }) // O(n)
        if (emailExist)
            return res.status(200).json({ success: false, message: "Employee with this Email ID Already Found!" })
        console.log(mapped.get('Lead'))
        let under = []
        if (mapped.get('Lead').includes(specialRole)) {
            const { over } = req.body
            if (over && over.length || [] > 0) {
                const list = await EmployeeRepo.checkEmployeesUnderTL(over, department, specialRole)
                for (let i of list) {
                    for (let j of over) {
                        if (i === j)
                            return res.status(200).json({ success: false, message: `Employee with ID: ${i} already under another TL!` })
                    }
                }
                for (let i of over) {
                    const details = await EmployeeRepo.getEmployeeDetails({ employeeId: i })
                    console.log(details)
                    if (details?.department !== department)
                        return res.status(200).json({ success: false, message: `Employee with ID: ${i} is not of Department: ${department}` })
                }
                under = over
            }
        }
        const crypted = await bcrypt.hash(password, 10)
        if (mapped.get('Lead').includes(specialRole)) {
            await EmployeeRepo.createEmployee({ employeeId, employeeEmail, firstName, lastName, department, role, specialRole, password: crypted, over: under }) // O(1)
        }
        else {
            await EmployeeRepo.createEmployee({ employeeId, employeeEmail, firstName, lastName, department, role, specialRole, password: crypted }) // O(1)
        }
        return res.status(200).json({ success: true, message: "Employee Created Successfully!", result: { employeeId, password } })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!" })
    }
}

export const updateEmployee = async (req, res) => { // O(n)
    try {
        const { employeeId, employeeEmail, firstName, lastName, department, role, specialRole } = req.body
        const exists = await EmployeeRepo.employeeExists({ employeeId }) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: "Employee Not Found!" })
        let under = []
        if (mapped.get('Lead').includes(specialRole)) {
            const { over } = req.body
            if (over && over.length || [] > 0) {
                const list = await EmployeeRepo.checkEmployeesUnderTLExcept(over, department, specialRole, employeeId)
                console.log(list)
                for (let i of list) {
                    for (let j of over) {
                        if (i === j)
                            return res.status(200).json({ success: false, message: `Employee with ID: ${i} already under another TL!` })
                    }
                }
                for (let i of over) {
                    const details = await EmployeeRepo.getEmployeeDetails({ employeeId: i })
                    console.log(details)
                    if (details?.department !== department)
                        return res.status(200).json({ success: false, message: `Employee with ID: ${i} is not of Department: ${department}` })
                }
                under = over
            }
        }

        if (mapped.get('Lead').includes(specialRole)) {
            await EmployeeRepo.modifyEmployee({ employeeId, employeeEmail, firstName, lastName, department, role, specialRole, over: under }) // O(1)
        }
        else {
            await EmployeeRepo.modifyEmployee({ employeeId, employeeEmail, firstName, lastName, department, role, specialRole }) // O(n)
        }
        return res.status(200).json({ success: true, message: "Employee Updated Successfully!" })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!" })
    }
}

export const deleteEmployee = async (req, res) => { // O(n)
    try {
        const { employeeId } = req.body
        const exists = await EmployeeRepo.employeeExists({ employeeId }) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: "Employee Not Found!" })
        await EmployeeRepo.removeEmployee(employeeId) // O(n)
        return res.status(200).json({ success: true, message: "Employee Deleted Successfully!" })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!" })
    }
}

export const getEmployee = async (req, res) => { // O(n)
    try {
        const { employeeId } = req.body
        const exists = await EmployeeRepo.employeeExists({ employeeId }) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: 'Employee Not Found!' })
        const details = await EmployeeRepo.getEmployeeDetails({ employeeId }) // O(n)
        return res.status(200).json({ success: true, result: details })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!" })
    }
}

export const loginEmployee = async (req, res) => { // O(n)
    try {
        const { employeeId, password } = req.body
        const exists = await EmployeeRepo.employeeExists({ employeeId }) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: 'Employee with this ID not found!' })
        const matches = await EmployeeRepo.checkPassword(password, employeeId) // O(2^c)
        if (!matches)
            return res.status(200).json({ success: false, message: 'Incorrect Password!' })
        const employeeDetails = await EmployeeRepo.getEmployeeDetails({ employeeId }) // O(n)
        const roleToGroup = new Map()
        for (const [group, roles] of mapped.entries()) {
            roles.forEach(role => {
                roleToGroup.set(role, group);
            });
        }
        const payload = {
            myId: employeeId,
            myRole: (() => {
                const specialRole = employeeDetails.specialRole
                const department = employeeDetails.department
                if (roleToGroup.has(specialRole) || specialRole !== 'None') {
                    return encryptData(specialRole)
                }
                if (specialRole === 'None') {
                    if (roleToGroup.has(department))
                        return encryptData(department)
                }
                return encryptData('Employee')
            })(),
            department: employeeDetails.department
        }
        console.log(payload)
        const token = jwt.sign(payload, secret_key, { expiresIn: '1h' })
        const move = EmployeeRepo.defineMove({ employeeDetails })
        return res.status(200).json({ success: true, message: 'Login Successful!', result: { token, move } })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: 'Something went wrong!' })
    }
}

export const verifyRole = async (employeeId, saidRole) => { // O(n)
    const employeeDetails = await EmployeeRepo.getEmployeeDetails({ employeeId })// O(n)
    if (employeeDetails === null)
        return false
    if (employeeDetails.department === saidRole || employeeDetails.specialRole === saidRole) {
        if (mapped.get('Management').includes(saidRole))
            return true
        return false
    }
}

export const getDepartmentsList = async (req, res) => { //O(1)
    try {
        const list = await getDepartments() // O(1)
        return res.status(200).json({ success: true, message: 'Got List', result: list })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: 'Something went wrong!' })
    }
}

export const getRolesList = async (req, res) => { // O(1)
    try {
        const list = await getRoles() // O(1)
        return res.status(200).json({ success: true, message: 'Got List', result: list })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: 'Something went wrong!' })
    }
}

export const getSpecialRolesList = async (req, res) => { // O(1)
    try {
        const list = await getSpecialRoles() // O(1)
        return res.status(200).json({ success: true, message: 'Got List', result: list })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: 'Something went wrong!' })
    }
}

export const signup = async (req, res) => {
    try {
        const { employeeId, employeeEmail, firstName, lastName, department, role, specialRole, password } = req.body
        const exists = await EmployeeRepo.employeeExists({ employeeId })
        if (exists)
            return res.status(200).json({ success: false, message: "Employee with this ID Already Found!" })
        const emailExist = await EmployeeRepo.emailExists({ employeeEmail })
        if (emailExist)
            return res.status(200).json({ success: false, message: "Employee with this Email ID Already Found!" })
        const crypted = await bcrypt.hash(password, 10)
        await EmployeeRepo.createEmployee({ employeeId, employeeEmail, firstName, lastName, department, role, specialRole, password: crypted })
        return res.status(200).json({ success: true, message: "Employee Created Successfully!" })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!" })
    }
}

export const decodeToken = async (req, res) => {
    const user = req.user
    console.log(user)
    return res.status(200).json({ success: true, message: "Token Decoded!", result: { user } })
}

export const requestChangePassword = async (req, res) => { // O(n)
    const { employeeId, employeeEmail } = req.body
    try {
        const exists = await EmployeeRepo.employeeExists({ employeeId }) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: "Enter a Valid ID", result: [] })
        const emailExist = await EmployeeRepo.emailExists({ employeeEmail }) // O(n)
        if (!emailExist)
            return res.status(200).json({ success: false, message: "Enter a Valid Email or Signup!", result: [] })
        const employeeDetails = await EmployeeRepo.getEmployeeDetails({ employeeId }) // O(n)
        if (employeeDetails.employeeEmail !== employeeEmail || employeeDetails.employeeId !== employeeId)
            return res.status(200).json({ success: false, message: "Your ID and Email not matches!", result: [] })
        return res.status(200).json({ success: true, message: "Credentials Valid!", result: [] })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}

export const changePassword = async (req, res) => {
    try {
        const { employeeId, newPassword, repeatedPassword } = req.body
        if (newPassword !== repeatedPassword)
            return res.status(200).json({ success: false, message: "Passwords didn't matches!", result: [] })
        const employeeDetails = await EmployeeRepo.getEmployeeDetails({ employeeId }) // O(n)
        const matchesOldPassword = await bcrypt.compare(newPassword, employeeDetails.password)
        if (matchesOldPassword)
            return res.status(200).json({ success: false, message: "Password should differ from old password!", result: [] })
        await EmployeeRepo.modifyPassword(employeeId, newPassword) // O(log n) or O(n)
        return res.status(200).json({ success: true, message: "Password Changed Successfully!", result: [] })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}

export const getRoleByToken = async (req, res) => {
    try {
        console.log(req.user)
        return res.status(200).json({ success: true, message: "Role parsed!", result: [decryptData(req.user.myRole)] })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}

export const getMyDetails = async (req, res) => { // O(n)
    try {
        const { employeeId } = req.body
        const exists = await EmployeeRepo.employeeExists({ employeeId }) // O(n)
        if (!exists)
            return res.status(200).json({ success: false, message: "Employee Not Found!" })
        const details = await EmployeeRepo.getEmployeeDetails({ employeeId }) // O(n)
        details['password'] = 'CONFIDENTIAL'
        const personalDetails = await EmployeeRepo.getEmployeePersonalDetails({ employeeId }) // O(n)
        return res.status(200).json({ success: true, message: "Got Employee Details!", result: { details, personalDetails } })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}

export const getHierarchy = async (req, res) => {
    try {
        const { departmentName } = req.body
        const authoritiesList = []
        for (const authority of approvalAuthorities)
            authoritiesList.push((await EmployeeRepo.getListOfAuthorities(departmentName, authority)))
        const hierarchy = new Map()
        hierarchy.set(departmentName, {
            tls: authoritiesList[0]?.ids || [],
            managers: authoritiesList[1]?.ids || [],
            employees: authoritiesList[2]?.ids || []
        })
        console.log('Hierarchy Map: ', hierarchy)
        return res.status(200).json({ success: true, message: "Hierarchy Made!", result: [...hierarchy] })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}

export const askLeave = async (req, res) => {
    try {
        const {employeeId,requestDates,reason} = req.body
        const exists = await EmployeeRepo.employeeExists({employeeId})
        if(!exists)
            return res.status(200).json({success:false,message:"Employee Not Found!",result:[]})
        console.log('Should mail for: ')
        console.log((await EmployeeRepo.prepareLeaveForm(employeeId,requestDates,reason)))
        return res.status(200).json({success:true,message:"Success",result:[]})
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}