import { verifyRole } from "../controllers/employee.js"
import { mapped } from "../editable.js"
import { decryptData } from "../helper.js";

export const authorizeRole = async (req, res, next) => {
    const currentRole = req.user.myRole ? decryptData(req.user.myRole) : null
    const currentId = req.user.myId || null
    console.log('ROLE: ', currentRole)
    if (!currentRole)
        return res.status(200).json({ success: false, message: 'Role must be specified!' })

    const allowedRoles = Array.from(mapped.values()).flat()
    console.log(allowedRoles)

    if (!allowedRoles.includes(currentRole))
        return res.status(200).json({ success: false, message: "Forbidden! You don't have authorization!" })

    if (!mapped.get('Administration').includes(currentRole)) {
        if (!currentId)
            return res.status(200).json({ success: false, message: 'Your ID must be specified!' })
        const isThatRole = await verifyRole(currentId, currentRole);
        if (!isThatRole)
            return res.status(200).json({ success: false, message: 'Forbidden! Unauthorized access!' })
    }
    next()
};