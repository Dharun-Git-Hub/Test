import jwt from "jsonwebtoken";

const secret_key = 'secret_key'

export const verifyJWT = async (req, res, next) => {
    try {
        const token = req.headers['token']
        console.log(req.headers)
        console.log(token)
        if (!token)
            return res.status(200).json({ success: false, message: "No token" });
        const decoded = jwt.decode(token)
        const verified = Date.now() < new Date(decoded.exp * 1000)
        if (!verified)
            return res.status(200).json({ success: false, message: 'TOKEN EXPIRED!', result: {move:'login'} })
        jwt.verify(token, secret_key, (err, user) => {
            if (err)
                return res.status(403).json({ message: "INVALID TOKEN", result: {move:'login'} });
            console.log(user)
            req.user = user;
            next();
        });
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: 'Invalid JWT Token', result: [] })
    }
}