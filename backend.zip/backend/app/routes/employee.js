import express from 'express'
import * as EmployeeController from '../controllers/employee.js'
import { authorizeRole } from '../middleware/authorizeRole.js'
import * as EmployeeValidator from '../validator/employeeValidator.js'
import { verifyJWT } from '../middleware/jwt.js'

const router = express.Router()

router.get('/',EmployeeController.sayHello)
router.post('/addEmployee',verifyJWT,authorizeRole,EmployeeValidator.validateRegister,EmployeeController.addEmployee)
router.patch('/updateEmployee',verifyJWT,authorizeRole,EmployeeValidator.updateEmployeeRegister,EmployeeController.updateEmployee)
router.post('/getEmployee',verifyJWT,authorizeRole,EmployeeValidator.getEmployeeRegister,EmployeeController.getEmployee)
router.delete('/deleteEmployee',verifyJWT,authorizeRole,EmployeeValidator.getEmployeeRegister,EmployeeController.deleteEmployee)
router.post('/loginEmployee',EmployeeValidator.loginRegister,EmployeeController.loginEmployee)
router.patch('/changePassword',EmployeeValidator.passwordValidator,EmployeeController.changePassword)
router.post('/getMyDetails',verifyJWT,EmployeeValidator.getMyDetailsValidator,EmployeeController.getMyDetails)
router.post('/requestChangePassword',EmployeeValidator.forgotPasswordValidator,EmployeeController.requestChangePassword)
router.post('/decodeToken',verifyJWT,EmployeeController.decodeToken)
router.get('/getDepartmentsList',verifyJWT,EmployeeController.getDepartmentsList)
router.get('/getRolesList',verifyJWT,EmployeeController.getRolesList)
router.get('/getSpecialRolesList',verifyJWT,EmployeeController.getSpecialRolesList)
router.get('/getRole',verifyJWT,EmployeeController.getRoleByToken)

router.post('/getHierarchy',EmployeeController.getHierarchy)
router.post('/askLeave',verifyJWT,EmployeeController.askLeave)

export default router