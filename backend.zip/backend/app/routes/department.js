import express from 'express'
import * as DepartmentControl from '../controllers/department.js'
import { authorizeRole } from '../middleware/authorizeRole.js'
import * as DepartmentValidator from '../validator/departmentValidator.js'
import { verifyJWT } from '../middleware/jwt.js'

const router = express.Router()

router.post('/getDepartment',verifyJWT,authorizeRole,DepartmentValidator.getDepartmentRegister,DepartmentControl.getDepartment)
router.post('/addNewDepartment',verifyJWT,authorizeRole,DepartmentValidator.getDepartmentRegister,DepartmentControl.addNewDepartment)
router.delete('/deleteExistingDepartment',verifyJWT,authorizeRole,DepartmentValidator.getDepartmentRegister,DepartmentControl.deleteExistingDepartment)
router.patch('/updateDepartment',verifyJWT,authorizeRole,DepartmentValidator.updateDepartmentRegister,DepartmentControl.updateDepartment)

export default router