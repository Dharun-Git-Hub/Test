import { validationResult } from "express-validator";
import dotenv from 'dotenv'
import crypto from 'crypto-js'

dotenv.config()

const aes_secret = process.env.AES_SECRET

export const removeExtensionFromFile = (file) => {
    return file.split('.').slice(0, -1).join('.').toString();
};

export const validateResult = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const firstError = errors.array()[0].msg;
        return res.status(200).json({ success: false, message: firstError });
    }
    if (req.body.email) {
        req.body.email = req.body.email.toLowerCase()
    }
    next();
};

export const encryptData = (data) => {
    const crypted = crypto.AES.encrypt(data,aes_secret).toString()
    console.log(crypted)
    return crypted
}

export const decryptData = (data) => {
    const decrypted = crypto.AES.decrypt(data,aes_secret)
    console.log(decrypted.toString(crypto.enc.Utf8))
    return decrypted.toString(crypto.enc.Utf8)
}