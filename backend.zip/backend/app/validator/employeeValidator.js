import { check } from "express-validator"
import { validateResult } from "../helper.js"

export const validateRegister = [

    check('employeeId')
        .exists()
        .withMessage('EMPLOYEE ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('firstName')
        .exists()
        .withMessage('First NAME MISSING')
        .not()
        .isEmpty()
        .withMessage('please fill First name')
        .isLength({ min: 4 })
        .withMessage('First Name must be at least 4 chars long')
        .matches(/^[A-Za-z0-9\s-]{1,16}$/)
        .withMessage('First name invalid format'),

    check('employeeEmail')
        .exists()
        .withMessage('EMAIL IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        .isEmail()
        .withMessage('EMAIL_IS_NOT_VALID'),

    check('password')
        .exists()
        .withMessage('PASSWORD MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        .matches(/(^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,16}$)+/)
        .withMessage('Password must be a minimum 8 characters & Maximum 16 characters.At least one lowercase,At least one uppercase,At least one digit and At least it should have 8 characters long.Eg: Abcd1234')
        .isLength({
            min: 5
        })
        .withMessage('PASSWORD_TOO_SHORT_MIN_5'),

    check('specialRole')
        .exists()
        .withMessage('SPECIAL ROLE MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('myrole')
        .exists()
        .withMessage('YOUR ROLE MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),



    check('department')
        .exists()
        .withMessage('EMPLOYEE DEPARTMENT IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('role')
        .exists()
        .withMessage('EMPLOYEE ROLE MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const loginRegister = [

    check('employeeId')
        .exists()
        .withMessage('EMPLOYEE ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('password')
        .exists()
        .withMessage('PASSWORD MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        .matches(/(^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,16}$)+/)
        .withMessage('Password must be a minimum 8 characters & Maximum 16 characters.At least one lowercase,At least one uppercase,At least one digit and At least it should have 8 characters long.Eg: Abcd1234')
        .isLength({
            min: 5
        })
        .withMessage('PASSWORD_TOO_SHORT_MIN_5'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const updateEmployeeRegister = [

    check('employeeId')
        .exists()
        .withMessage('EMPLOYEE ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('firstName')
        .exists()
        .withMessage('First NAME MISSING')
        .not()
        .isEmpty()
        .withMessage('please fill First name')
        .isLength({ min: 4 })
        .withMessage('First Name must be at least 4 chars long')
        .matches(/^[A-Za-z0-9\s-]{1,16}$/)
        .withMessage('First name invalid format'),

    check('employeeEmail')
        .exists()
        .withMessage('EMAIL IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        .isEmail()
        .withMessage('EMAIL_IS_NOT_VALID'),

    check('specialRole')
        .exists()
        .withMessage('SPECIAL ROLE MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('myrole')
        .exists()
        .withMessage('YOUR ROLE MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),



    check('department')
        .exists()
        .withMessage('EMPLOYEE DEPARTMENT IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('role')
        .exists()
        .withMessage('EMPLOYEE ROLE MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const getEmployeeRegister = [

    check('employeeId')
        .exists()
        .withMessage('EMPLOYEE ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('myrole')
        .exists()
        .withMessage('YOUR ROLE IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const passwordValidator = [
    check('newPassword')
        .exists()
        .withMessage('PASSWORD MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        .matches(/(^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,16}$)+/)
        .withMessage('Password must be a minimum 8 characters & Maximum 16 characters.At least one lowercase,At least one uppercase,At least one digit and At least it should have 8 characters long.Eg: Abcd1234')
        .isLength({
            min: 5
        })
        .withMessage('PASSWORD_TOO_SHORT_MIN_5'),

    check('repeatedPassword')
        .exists()
        .withMessage('REPEATED PASSWORD MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        .matches(/(^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,16}$)+/)
        .withMessage('Password must be a minimum 8 characters & Maximum 16 characters.At least one lowercase,At least one uppercase,At least one digit and At least it should have 8 characters long.Eg: Abcd1234')
        .isLength({
            min: 5
        })
        .withMessage('PASSWORD_TOO_SHORT_MIN_5'),


    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const getMyDetailsValidator = [

    check('employeeId')
        .exists()
        .withMessage('EMPLOYEE ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const forgotPasswordValidator = [
    check('employeeId')
        .exists()
        .withMessage('EMPLOYEE ID IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('employeeEmail')
        .exists()
        .withMessage('EMAIL IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY')
        .isEmail()
        .withMessage('EMAIL_IS_NOT_VALID'),

    (req, res, next) => {
        validateResult(req, res, next)
    }
]