import { check } from "express-validator"
import { validateResult } from "../helper.js"

export const getDepartmentRegister = [

    check('departmentName')
        .exists()
        .withMessage('DEPARTMENT NAME IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),
        
    check('myrole')
        .exists()
        .withMessage('YOUR ROLE IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),
    

        
    (req, res, next) => {
        validateResult(req, res, next)
    }
]

export const updateDepartmentRegister = [

    check('departmentName')
        .exists()
        .withMessage('DEPARTMENT NAME IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),

    check('newName')
        .exists()
        .withMessage('NEW NAME IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),
        
    check('myrole')
        .exists()
        .withMessage('YOUR ROLE IS MISSING')
        .not()
        .isEmpty()
        .withMessage('IS_EMPTY'),
    

        
    (req, res, next) => {
        validateResult(req, res, next)
    }
]