import bcrypt from 'bcrypt'
import { Employee } from "../models/employee.js";
import { Personal } from "../models/personal.js";
import { Admin } from "../models/admin.js";
import { Department } from "../models/department.js";
import { isIDExists } from "./department.js";
import { mapped } from "../editable.js";

export const createEmployee = async (details) => {
    await Employee.create({ ...details })
    const exists = await Department.exists({ departmentName: details.department })
    if (!exists)
        await Department.create({ departmentName: details.department })
    const idExists = await isIDExists(details.employeeId)
    if (idExists)
        return
    await Department.updateOne(
        {
            departmentName: details.department
        },
        {
            $push: {
                employees: details.employeeId
            }
        }
    )
}

export const modifyEmployee = async (details) => {
    const { employeeId, employeeEmail, firstName, lastName, department, role, specialRole } = details
    if (mapped.get('Lead').includes(specialRole)) {
        const { over } = details
        await Employee.updateOne(
            {
                employeeId
            },
            {
                $set: {
                    employeeEmail,
                    firstName,
                    lastName,
                    department,
                    role,
                    specialRole,
                    over
                }
            }
        )
    }
    else {
        await Employee.updateOne(
            {
                employeeId
            },
            {
                $set: {
                    employeeEmail,
                    firstName,
                    lastName,
                    department,
                    role,
                    specialRole
                }
            }
        )
    }
}

export const removeEmployee = async (employeeId) => {
    await Employee.deleteOne({ employeeId })
    const idExists = await isIDExists(employeeId)
    if (!idExists)
        return
    await Department.updateMany(
        {},
        {
            $pull: {
                employees: employeeId
            }
        }
    )
}

export const getEmployeeDetails = async (details) => {
    const { employeeId } = details
    const exists = await Employee.findOne({ employeeId })
    return exists
}

export const findRole = async (details) => {
    const { employeeId } = details
    const exists = await Employee.findOne({ employeeId })
    if (!exists)
        return false
    return exists.role
}

export const findDepartment = async (details) => {
    const { employeeId } = details
    const exists = await Employee.findOne({ employeeId })
    if (!exists)
        return false
    return exists.department
}

export const findSpecialRole = async (details) => {
    const { employeeId } = details
    const exists = await Employee.findOne({ employeeId })
    if (!exists)
        return false
    return exists.specialRole
}

export const getEmployeePersonalDetails = async (details) => {
    const { employeeId } = details
    const exists = await Personal.findOne({ employeeId })
    if (!exists)
        return exists
    return exists
}

export const employeeExists = async (details) => {
    const exists = await Employee.exists({ ...details })
    if (!exists)
        return false
    return true
}

export const emailExists = async ({ employeeEmail }) => {
    const exists = await Employee.exists({ employeeEmail })
    if (!exists)
        return false
    return true
}

export const employeePersonalDetailsExists = async (details) => {
    const exists = await Personal.exists({ ...details })
    if (!exists)
        return false
    return true
}

export const createPersonalDetails = async (details) => {
    await Personal.create({ ...details })
}

export const updateEmployeePersonalDetails = async (details) => {
    const { employeeId, salary, loss, awards } = details
    await Personal.updateOne(
        {
            employeeId
        },
        {
            $set: {
                salary,
                loss,
                awards
            }
        }
    )
}

export const adminExists = async (employeeEmail) => {
    const exists = await Admin.findOne({ employeeEmail })
    if (!exists)
        return false
    return true
}

export const verifyPassword = async ({ employeeEmail, password }) => {
    const details = await Admin.findOne({ employeeEmail })
    const matches = await bcrypt.compare(password, details.password)
    if (matches)
        return true
    return false
}

export const checkPassword = async (password, employeeId) => {
    const details = await getEmployeeDetails({ employeeId })
    const matches = await bcrypt.compare(password, details.password)
    if (!matches)
        return false
    return true
}

export const defineMove = ({ employeeDetails }) => {
    if (employeeDetails.specialRole !== 'None')
        return employeeDetails.specialRole
    else if (mapped.get('Management').includes(employeeDetails.department))
        return employeeDetails.department
    return 'Employee'
}

export const modifyPassword = async (employeeId, newPassword) => {
    const crypted = await bcrypt.hash(newPassword, 10)
    await Employee.updateOne(
        { employeeId },
        {
            $set: {
                password: crypted
            }
        }
    )
}

export const getListOfAuthorities = async (departmentName, authority) => {
    const pipeline = [
        {
            $group: {
                _id: '$department',
                employees: { $push: '$$ROOT' }
            }
        },
        {
            $unwind: '$employees'
        },
        {
            $match: {
                $and: [
                    { 'employees.department': departmentName },
                    { 'employees.specialRole': authority }
                ]
            }
        },
        {
            $group: {
                _id: null,
                ids: { $push: '$employees.employeeId' }
            }
        },
        {
            $project: {
                _id: 0,
                ids: 1
            }
        }
    ]
    const result = await Employee.aggregate(pipeline)
    return result
}

export const checkEmployeesUnderTL = async (over, department, specialRole) => {
    const list = await getListOfAuthorities(department, specialRole);
    const arrayOfEmployees = [];

    for (let i of list[0]?.ids || []) {
        const employee = await Employee.findOne({ employeeId: i });

        if (employee?.over) {
            if (Array.isArray(employee.over)) {
                arrayOfEmployees.push(...employee.over)
            } else {
                arrayOfEmployees.push(employee.over)
            }
        }
    }
    console.log('Employees Array:', arrayOfEmployees);
    return arrayOfEmployees;
}

export const checkEmployeesUnderTLExcept = async (over, department, specialRole, employeeId) => {
    const list = await getListOfAuthorities(department, specialRole);
    const arrayOfEmployees = [];

    for (let i of list[0]?.ids || []) {
        if (i === employeeId)
            continue
        const employee = await Employee.findOne({ employeeId: i });

        if (employee?.over) {
            if (Array.isArray(employee.over)) {
                arrayOfEmployees.push(...employee.over)
            } else {
                arrayOfEmployees.push(employee.over)
            }
        }
    }
    console.log('Employees Array:', arrayOfEmployees);
    return arrayOfEmployees;
}

export const prepareLeaveForm = async (employeeId, requestDates, reason) => {
    let authorities = []
    const details = await getEmployeeDetails({ employeeId })
    const higherAuthorities = Array.from(mapped.values()).flat()

    if (!higherAuthorities.includes(details.role) && !higherAuthorities.includes(details.specialRole)) {
        authorities = higherAuthorities
    } else if (mapped.get('Lead').includes(details.specialRole)) {
        authorities = mapped.get('Management')
    }
    let tempId = []
    const mailIds = new Set()
    for (const i of authorities) {
        const authorityIds = (await getListOfAuthorities(details.department, i))[0]?.ids || [];
        tempId.push(...authorityIds)
    }

    console.log('TEMP ID: ', tempId)
    let hrs = await getHRsList()
    hrs.forEach((hrArray) => {
        hrArray.forEach((e) => tempId.push(e.employeeId))
    })

    for (const id of tempId) {
        mailIds.add((await Employee.findOne({ employeeId: id }))?.employeeEmail)
    }
    console.log('LIST OF AUTHORITIES: ', tempId)
    console.log(mailIds)
    mailIds.forEach(e => console.log(`Send Email for ${reason} on ${requestDates.join(", ")} to Email: ${e}`))
    return authorities
}

export const getHRsList = async () => {
    let result = []
    for (const i of mapped.get('Management')) {
        let temp = await Employee.find({ department: i })
        if (temp.length > 0) {
            result.push([...temp])
        }
    }
    return result
}