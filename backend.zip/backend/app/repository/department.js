import { Department } from "../models/department.js"
import { Role } from "../models/roles.js"
import { SpecialRole } from "../models/specialRoles.js"

export const isDepartmentExists = async (departmentName) => {
    const exists = await Department.findOne({ departmentName })
    if (!exists)
        return false
    return true
}

export const addDepartment = async (departmentName) => {
    await Department.create({ departmentName, employees: [] })
}

export const deleteDepartment = async (departmentName) => {
    await Department.deleteOne({ departmentName })
}

export const getDepartmentDetails = async (departmentName) => {
    const res = await Department.findOne({ departmentName })
    return res
}

export const updateDepartmentName = async (departmentName, newName) => {
    await Department.updateOne(
        {
            departmentName
        },
        {
            $set: {
                departmentName: newName
            }
        }
    )
}

export const isIDExists = async (employeeId) => {
    const exists = await Department.findOne({
        employees: { $in: [employeeId] }
    })
    if (!exists)
        return false
    return true
}

export const loadDepartments = async () => {
    const departments = ['HR', 'Development', 'UI/UX', 'Frontend', 'Backend', 'FullStack']
    const roles = ['Intern', 'Junior', 'Senior', 'Professional']
    const specialRoles = ['TL', 'Manager', 'ActiveTL', 'None']

    for (let dept of departments) {
        const exists = await Department.exists({ departmentName: dept })
        if (!exists) {
            await Department.create({
                departmentName: dept,
                employees: []
            })
        }
    }

    for (let role of roles) {
        const exists = await Role.exists({ role })
        if (!exists) {
            await Role.create({
                role
            })
        }
    }

    for (let specialRole of specialRoles) {
        const exists = await SpecialRole.exists({ role: specialRole})
        if (!exists) {
            await SpecialRole.create({
                role: specialRole
            })
        }
    }
}

export const getDepartments = async () => {
    const pipeline = [
        {
            $group: {
                _id: '$departmentName',
            }
        }
    ]
    const result = await Department.aggregate(pipeline)
    const names = result.map(e=>e._id)
    return names
}

export const getRoles = async () => {
    const pipeline = [
        {
            $group: {
                _id: '$role',
            }
        }
    ]
    const result = await Role.aggregate(pipeline)
    return result.map(e=>e._id)
}

export const getSpecialRoles = async () => {
    const pipeline = [
        {
            $group: {
                _id: '$role',
            }
        }
    ]
    const result = await SpecialRole.aggregate(pipeline)
    return result.map(e=>e._id)
}