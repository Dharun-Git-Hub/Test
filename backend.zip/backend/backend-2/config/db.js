import mongoose from 'mongoose';
import dotenv from 'dotenv'
import { seedRolesAndMappings } from '../app/seed/seed.js';

dotenv.config()

export const connectToDatabase = async () => {
    const MONGO_URI = process.env.MONGO_URI
    try {
        await mongoose.connect(MONGO_URI);
        console.log('MongoDB Connected!');
        await seedRolesAndMappings()
    }
    catch (err) {
        console.error('Error connecting to the database', err);
        process.exit(1);
    }
};
