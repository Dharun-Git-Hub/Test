import express from 'express'
import * as EmployeeController from '../controllers/employee.js'
import * as Middlewares from '../middleware/authRole.js'
import * as EmployeeValidators from '../validator/employeeValidator.js'

const router = express.Router()

router.get('/',EmployeeController.sayHello)
router.post('/addEmployee',Middlewares.verifyJWT,EmployeeValidators.addEmployeeReg,Middlewares.authRole('create'),EmployeeController.addEmployee)
router.patch('/updateEmployee',Middlewares.verifyJWT,EmployeeValidators.updateEmployeeReg,Middlewares.authRole('update'),EmployeeController.updateEmployee)
router.delete('/deleteEmployee',Middlewares.verifyJWT,EmployeeValidators.deleteEmployeeReg,Middlewares.authRole('delete'),EmployeeController.deleteEmployee)
router.post('/getEmployee',Middlewares.verifyJWT,EmployeeValidators.deleteEmployeeReg,Middlewares.authRole('read'),EmployeeController.getEmployee)
router.get('/getAllEmployees',Middlewares.verifyJWT,Middlewares.authRole('read'),EmployeeController.getAllEmployees)
router.post('/loginEmployee',EmployeeValidators.loginEmployeeValidator,EmployeeController.loginEmployee)
router.post('/requestChangePassword',EmployeeValidators.forgotPasswordValidator,EmployeeController.requestChangePassword)
router.patch('/changePassword',EmployeeValidators.changePasswordValidator,EmployeeController.changePassword)

router.get('/decodeToken',EmployeeController.decodeToken)
router.post('/askForLeave',Middlewares.verifyJWT,EmployeeController.askForLeave)


export default router