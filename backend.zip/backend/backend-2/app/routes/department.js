import express from 'express'
import * as DepartmentController from "../controllers/department.js"
import * as Middlewares from "../middleware/authRole.js"
import * as DepartmentValidator from '../validator/departmentValidator.js'

const router = express.Router()

router.post('/addDepartment',DepartmentValidator.addDepartmentValidator,Middlewares.verifyJWT,Middlewares.authRole('create'),DepartmentController.addDepartment)
router.delete('/deleteDepartment',DepartmentValidator.addDepartmentValidator,Middlewares.verifyJWT,Middlewares.authRole('delete'),DepartmentController.deleteDepartment)
router.get('/getDepartmentsList',Middlewares.verifyJWT,Middlewares.authRole('read'),DepartmentController.getDepartmentsList)
router.patch('/updateDepartment',DepartmentController.updateDepartment)

export default router