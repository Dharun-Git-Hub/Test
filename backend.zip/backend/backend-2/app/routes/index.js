import express from 'express';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import fs from 'fs';
import { removeExtensionFromFile } from '../helper/helper.js'

const router = express.Router();
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const routesPath = __dirname;

const loadRoutes = async () => {
    try{
        const routeFiles = fs.readdirSync(routesPath).filter((file) => {
            return file !== 'index.js' && file !== 'auth.js' && !file.startsWith('.');
        });

        for(const file of routeFiles){
            const routeModule = await import(`./${file}`);
            if(routeModule.default){
                const routeName = removeExtensionFromFile(file);
                router.use(`/${routeName}`, routeModule.default);
            }
            else
                console.error(`${file} did not export a default router.`);
        }
    }
    catch(err){
        console.error("Error loading routes:", err);
    }
}

loadRoutes();

export default router;
