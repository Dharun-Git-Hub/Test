import { Counter } from "../models/counter.js"
import { Department } from "../models/department.js"
import { Employee } from "../models/employee.js"

export const getIfAnyDepartment = async (departmentName) => {
    const exists = await Department.findOne(departmentName)
    return exists
}

export const addNewDepartment = async (departmentName) => {
    await Department.findOneAndUpdate(
        { departmentName },
        { departmentName },
        { new: true, upsert: true }
    )
}

export const getAllDepartments = async () => {
    const list = await Department.find()
    if(!list) return null
    return list.map(e=>e.departmentName)
}

export const removeDepartment = async (departmentName) => {
    await Department.deleteOne({departmentName})
}

export const initializeCounter = async () => {
    const counterDetails = await Counter.findOne({})
    if(!counterDetails)
        Counter.create({current:0})
}

export const updateDepartmentName = async (oldName,newName) => {
    await Department.updateOne({departmentName:oldName},{$set: {departmentName:newName}})
    await Employee.updateMany({department:oldName},{$set: {department:newName}})
}