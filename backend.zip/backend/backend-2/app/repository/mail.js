import * as MailFormats from "../constants/constants.js"
import { Mail } from "../models/mailformat.js"

export const seedMailFormats = async () => {
    for(const i in MailFormats.templates){
        await Mail.create({reason:i,})
    }
}