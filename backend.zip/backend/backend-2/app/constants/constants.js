export const departments = ["FullStack", "UI/UX", "Frontend", "Backend", "HR"]

const emailTemplates = {
  leaveMail: [
    {
      subject: "Leave Application for [Date]",
      body: `Dear [Manager's Name],

I hope this message finds you well. I would like to apply for leave on [Date] due to [Reason – e.g., personal reasons / medical emergency / family function].

Please let me know if any further details are needed. I will ensure all pending tasks are up to date before my leave.

Thank you for your understanding.

Best regards,  
[Your Name]`
    },
    {
      subject: "Requesting Leave for [Start Date] to [End Date]",
      body: `Hi [Manager's Name],

I am writing to formally request leave from [Start Date] to [End Date]. The reason for the leave is [brief reason]. I will ensure that my responsibilities are covered during this period.

Kindly approve my request at your earliest convenience.

Thanks & Regards,  
[Your Name]`
    },
    {
      subject: "Casual Leave Request",
      body: `Respected [Manager's Name],

I would like to apply for a casual leave on [Date] due to [short reason]. I will resume work on [Next Working Date] and catch up on any missed tasks.

Looking forward to your approval.

Sincerely,  
[Your Name]`
    }
  ],

  lateComingMail: [
    {
      subject: "Late Arrival Notification",
      body: `Dear [Manager's Name],

I wanted to inform you that I will be arriving late to work today due to [Reason – traffic / health issue / personal commitment]. I expect to reach by [Time].

Thank you for your understanding.

Regards,  
[Your Name]`
    },
    {
      subject: "Coming Late to Office Today",
      body: `Hi [Manager's Name],

Apologies for the inconvenience. I will be reporting late to work today due to [Reason]. I will make sure to compensate for the lost time.

Regards,  
[Your Name]`
    },
    {
      subject: "Delay in Office Arrival",
      body: `Dear [Manager's Name],

This is to inform you that I am running late and will reach the office by [Expected Time]. The delay is due to [Reason].

Appreciate your understanding.

Best,  
[Your Name]`
    }
  ],

  fingerprintMissedMail: [
    {
      subject: "Missed Fingerprint Punch - [Date]",
      body: `Dear [HR/Admin Name],

I would like to inform you that I missed my fingerprint punch on [Date] due to [Reason – technical issue / forgot / system error]. Kindly mark my attendance manually for the day.

Thank you for your assistance.

Regards,  
[Your Name]`
    },
    {
      subject: "Biometric Punch Missed",
      body: `Hi [HR/Admin Name],

This is to bring to your notice that I missed punching in/out on [Date]. The reason for the same is [brief reason]. Please take necessary action.

Thanks,  
[Your Name]`
    },
    {
      subject: "Missed Attendance Punch",
      body: `Respected [HR/Admin Name],

I forgot to punch in/out on [Date] due to [Reason]. Please consider my presence for that day.

Thank you,  
[Your Name]`
    }
  ],

  permissionMail: [
    {
      subject: "Permission to Leave Early",
      body: `Dear [Manager's Name],

I am writing to request permission to leave the office early on [Date] at [Time] due to [Reason]. I will ensure that all urgent tasks are completed beforehand.

Kindly grant me permission.

Best regards,  
[Your Name]`
    },
    {
      subject: "Request for Short Leave",
      body: `Hi [Manager's Name],

I need to step out for a short period on [Date] between [Time Range] due to [Reason]. Please consider this as a formal permission request.

Thanks in advance.

Regards,  
[Your Name]`
    },
    {
      subject: "Permission Required for [Reason]",
      body: `Dear [Manager's Name],

I seek your permission to [leave early / come late / take a short break] on [Date] because of [Reason]. I will ensure it doesn't affect any deliverables.

Thank you for your consideration.

Sincerely,  
[Your Name]`
    }
  ]
};

export const templates = {
    "leaveMail": emailTemplates.leaveMail,
    "lateComingMail": emailTemplates.lateComingMail,
    "fingerprintMissedMail": emailTemplates.fingerprintMissedMail,
    "permissionMail": emailTemplates.permissionMail
}