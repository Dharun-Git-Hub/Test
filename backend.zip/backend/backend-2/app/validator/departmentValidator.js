import { check } from "express-validator";
import { validateResult } from "../helper/helper.js";

export const addDepartmentValidator = [
    check("departmentName")
        .exists()
        .withMessage("DEPARTMENT NAME IS MISSING")
        .not()
        .isEmpty()
        .withMessage("IS_EMPTY"),

    (req, res, next) => {
        validateResult(req, res, next);
    },
]