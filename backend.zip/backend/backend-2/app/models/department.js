import mongoose from "mongoose";

const department = new mongoose.Schema({
    departmentName: { type: String, required: true },
})

export const Department = mongoose.model('Department',department)