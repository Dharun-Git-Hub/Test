import mongoose from "mongoose";

const mailFormat = new mongoose.Schema({
    reason: { type: String, required: true, unique: true },
    templates: [
         {
            subject: { type: String, required: true },
            body: { type: String, required: true }
         }
    ]
})

export const Mail = mongoose.model('Mail',mailFormat)