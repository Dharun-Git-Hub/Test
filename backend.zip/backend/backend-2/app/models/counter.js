import mongoose from "mongoose";

const counter = new mongoose.Schema({
    current: Number
})

export const Counter = mongoose.model('Counter',counter)