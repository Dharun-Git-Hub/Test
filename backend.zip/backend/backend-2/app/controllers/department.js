import * as DepartmentRepo from "../repository/department.js"

export const getDepartmentsList = async (req,res) => {
    const list = await DepartmentRepo.getAllDepartments()
    return res.status(200).json({success:true,message:"Departments List Retrieved!",list})
}

export const addDepartment = async (req,res) => {
    try{
        const {departmentName} = req.body
        console.log("departmentName: "+departmentName)
        const exists = await DepartmentRepo.getIfAnyDepartment({departmentName})
        if(exists)
            return res.status(200).json({success:false,message:"Department Already Found!",result:[]})
        await DepartmentRepo.addNewDepartment(departmentName)
        return res.status(200).json({success:true,message:"Department Created Successfull!",result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const deleteDepartment = async (req,res) => {
    const {departmentName} = req.body
    const exists = await DepartmentRepo.getIfAnyDepartment({departmentName})
    if(!exists)
        return res.status(200).json({success:false,message:"Department Not Found!",result:[]})
    await DepartmentRepo.removeDepartment(departmentName)
    return res.status(200).json({success:true,message:"Department Deleted Successfull!",result:[]})
}

export const updateDepartment = async (req,res) => {
    try{
        const {departmentName,newName} = req.body
        const exists = await DepartmentRepo.getIfAnyDepartment({departmentName})
        if(!exists)
            return res.status(200).json({success:false,message:"Department Not Found!",result:[]})
        await DepartmentRepo.updateDepartmentName(departmentName,newName)
        return res.status(200).json({success:true,message:"Department Renamed Successfully!",result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}