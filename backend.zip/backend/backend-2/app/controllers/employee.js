import * as EmployeeRepo from "../repository/employee.js"
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import * as RoleRepo from "../repository/role.js"
import { hrRoles, leaderRoles, managementRoles } from "../helper/helper.js"
import * as DepartmentRepo from "../repository/department.js"

const jwt_secret = "jwt_secret"

export const sayHello = async (req,res) => {
    return res.status(200).json({success:true,message:"Hello! Employee!",result:[]})
}

export const addEmployee = async (req,res) => {
    try{
        const {firstName,lastName,email,password,department,specialRole,under} = req.body
        const emailExists = await EmployeeRepo.employeeExists({email})
        if(emailExists)
            return res.status(200).json({success:false,message:"Employee Email already found!",result:[]})
        const roleDoc = await EmployeeRepo.getRoleForEmployee(department,specialRole)
        if (!roleDoc)
            return res.status(400).json({ success: false, message: "No valid role mapping found!" });
        const departmentExists = await DepartmentRepo.getIfAnyDepartment({departmentName:department})
        if(!departmentExists)
            return res.status(400).json({ success: false, message: "No such department found!" });
        const hashed = await bcrypt.hash(password,10)
        let employeeId = "FC" + (0o0 + (await EmployeeRepo.generateLatestId())).toString().padStart(4, '0');
        const idExists = await EmployeeRepo.employeeExists({employeeId})
        if(idExists)
            return res.status(200).json({success:false,message:"Employee ID already found!",result:[]})
        console.log(roleDoc.roleName)
        if(under.length > 0){
            if(under.includes(employeeId))
                return res.status(400).json({ success: false, message: "Employee should not contain his own ID in associated Array!!" });
            const isExistsUnder = await EmployeeRepo.getAllIfExists({department})
            console.log('IS EXISTS UNDER ',isExistsUnder)
            if(!isExistsUnder)
                return res.status(400).json({ success: false, message: `No Employees found under department - ${department} !` });
            for(const employee of isExistsUnder){
                if(employee.under?.length > 0){
                    for(let empId of under){
                        if(employee.under.includes(empId))
                            return res.status(400).json({ success: false, message: `Employee - ${empId} is already found under someone!` });
                    }
                }
            }
            for(const id of under){
                let details = await EmployeeRepo.getIfExists({employeeId:id})
                if(!details)
                    return res.status(400).json({ success: false, message: `No such employee ${id} found!` });
                if(details.department !== department)
                    return res.status(400).json({ success: false, message: `Employee - ${id} is not your department` });
            }
        }
        await EmployeeRepo.createEmployee({firstName,lastName,employeeId,email,password:hashed,department,specialRole,role:roleDoc._id,under,firstLogin:false})
        await EmployeeRepo.incrementCounter()
        return res.status(200).json({success:true,message:"Employee created successfully!",credentials:{employeeId,password},result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong",result:[]})
    }
}

export const updateEmployee = async (req,res) => {
    try{
        const {firstName,lastName,employeeId,email,department,specialRole,under} = req.body
        const idExists = await EmployeeRepo.employeeExists({employeeId})
        if(!idExists)
            return res.status(200).json({success:false,message:`Employee with ID: ${employeeId} Not found!`,result:[]})
        const emailExists = await EmployeeRepo.getIfExists({email})
        if(emailExists && emailExists.employeeId !== employeeId)
            return res.status(200).json({success:false,message:"This Email is already found!",result:[]})
        if(under.length > 0){
            if(under.includes(employeeId))
                return res.status(200).json({ success: false, message: "Employee should not contain his own ID in associated Array!!" });
            const isExistsUnder = await EmployeeRepo.getAllIfExists({department, employeeId: { $ne: employeeId } } )
            if(!isExistsUnder)
                return res.status(200).json({ success: false, message: `No Employees found under department - ${department} !` });
            for(const id of under){
                let details = await EmployeeRepo.getIfExists({employeeId:id})
                if(!details)
                    return res.status(200).json({ success: false, message: `No such employee ${id} found!` });
                if(details.department !== department)
                    return res.status(200).json({ success: false, message: `Employee - ${id} is not your department` });
            }
            for(const employee of isExistsUnder){
                if(employee.under?.length > 0){
                    for(let empId of under){
                        if(employee.under.includes(empId))
                            return res.status(200).json({ success: false, message: `Employee - ${empId} is already found under someone!` });
                    }
                }
            }
        }
        console.log('UPDATED: ',{firstName,lastName,email,department,specialRole,under})
        await EmployeeRepo.modifyEmployee(employeeId,{firstName,lastName,email,department,specialRole,under})
        return res.status(200).json({success:true,message:"Employee Updated Successfully!",result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const deleteEmployee = async (req,res) => {
    try{
        const {employeeId} = req.body
        const idExists = await EmployeeRepo.employeeExists({employeeId})
        if(!idExists)
            return res.status(200).json({success:false,message:"Employee Not found!",result:[]})
        await EmployeeRepo.removeEmployee({employeeId})
        await EmployeeRepo.removeEmployeeFromUnder([{ under: employeeId },{ $pull: { under: employeeId } }])
        return res.status(200).json({success:true,message:"Employee Deleted Successfully!",result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const getAllEmployees = async (req,res) => {
    try{
        const details = await EmployeeRepo.getAllIfExists({})
        console.log(details)
        return res.status(200).json({success:true,message:"Fetched All Employees!",result:[...details]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const getEmployee = async (req,res) => {
    try{
        const {employeeId} = req.body
        const idExists = await EmployeeRepo.getIfExists({employeeId})
        if(!idExists)
            return res.status(200).json({success:false,message:"Employee Not Found!",result:[]})
        return res.status(200).json({success:true,message:"Employee retrieved!",employeeData:idExists,result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const loginEmployee = async (req,res) => {
    try{
        const {employeeId,password} = req.body
        const idExists = await EmployeeRepo.employeeExists({employeeId})
        if(!idExists)
            return res.status(200).json({success:false,message:"Sorry, we can't get your details. Why won't you signup first?",result:[]})
        const isMatching = await EmployeeRepo.comparePassword(employeeId,password)
        if(!isMatching)
            return res.status(200).json({success:false,message:"Incorrect Password!",result:[]})
        const details = await EmployeeRepo.getIfExists({employeeId})
        const payload = {
            myId: details._id.toString(),
            myRole: details.role.toString(),
            department: details.department
        }
        const token = jwt.sign(payload,jwt_secret,{expiresIn:'1h'})
        return res.status(200).json({success:true,message:"Login Successful!",token,result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const requestChangePassword = async (req,res) => {
    try{
        const {employeeId,email} = req.body
        const idExists = await EmployeeRepo.employeeExists({employeeId})
        if(!idExists)
            return res.status(200).json({success:false,message:"Invalid ID! Sorry, we can't get your details. Why won't you signup first?",result:[]})
        const emailExists = await EmployeeRepo.employeeExists({email})
        if(!emailExists)
            return res.status(200).json({success:false,message:"This is not a registered Email!",result:[]})
        const details = await EmployeeRepo.getIfExists({employeeId})
        if(details.email !== email)
            return res.status(200).json({success:false,message:"This Email is not associated with this account!",result:[]})
        return res.status(200).json({success:true,message:"Credentials Checked!",result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const changePassword = async (req,res) => {
    try{
        const {employeeId,email,newPassword,repeated} = req.body
        if(newPassword !== repeated)
            return res.status(200).json({success:false,message:"New Password and Repeated Passwords aren't matching!"})
        const idExists = await EmployeeRepo.employeeExists({employeeId})
        if(!idExists)
            return res.status(200).json({success:false,message:"Invalid ID! Sorry, we can't get your details. Why won't you signup first?",result:[]})
        const emailExists = await EmployeeRepo.employeeExists({email})
        if(!emailExists)
            return res.status(200).json({success:false,message:"This is not a registered Email!",result:[]})
        const details = await EmployeeRepo.getIfExists({employeeId})
        if(details.email !== email)
            return res.status(200).json({success:false,message:"This Email is not associated with this account!",result:[]})
        if((await bcrypt.compare(newPassword,details.password)))
            return res.status(200).json({success:false,message:"New Password should not be as same as Old Password!",result:[]})
        await EmployeeRepo.modifyPassword(employeeId,newPassword)
        return res.status(200).json({success:true,message:"Password changed Successfully!",result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const decodeToken = async (req,res) => {
    try{
        const token = req.headers['token'] || null
        if(!token)
            return res.status(200).json({success:false,message:"No TOKEN Found!",result:[]})
        const data = jwt.decode(token)
        console.log(data)
        return res.status(200).json({success:true,message:"Token Decoded!",data,result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

export const askForLeave = async (req,res) => {
    try{
        let employeeId = req.user.myId
        const details = await EmployeeRepo.getById(employeeId)
        employeeId = details.employeeId
        console.log('EMPLOYEE ID: '+employeeId)
        if(!details)
            return res.status(200).json({success:false,message:"No Such Employee Found!",result:[]})
        const role = await RoleRepo.getRoleById({_id:details.role})
        if(!role)
            return res.status(200).json({success:false,message:"No Role Assigned!",result:[]})
        let authorities = []
        let currentRole = await EmployeeRepo.getRoleForEmployee(details.department,details.specialRole)
        let authoritiesList = []
        let mailers = []
        if(currentRole.roleName === 'Employee'){
            authorities = [...managementRoles,...leaderRoles]
            authoritiesList = await EmployeeRepo.getAllIfExists({department:details.department, specialRole: { $in: [...managementRoles, ...leaderRoles] }})
            let tls = authoritiesList.filter(e=>authorities.includes(e.specialRole) && e.under.includes(employeeId))
            console.log("TLS: LIST: ",tls)
            let managers = authoritiesList.filter(e=>authorities.includes(e.specialRole) && e.under.includes(tls[0].employeeId))
            mailers = [...tls,...managers].map(e=>e.email)
        }
        else if(currentRole.roleName === 'Leader'){
            authorities = [...managementRoles]
            authoritiesList = await EmployeeRepo.getAllIfExists({department:details.department, specialRole: { $in: [...managementRoles] }})
            let managers = authoritiesList.filter(e=>authorities.includes(e.specialRole) && e.under.includes(employeeId))
            mailers = managers.map(e=>e.email)
        }
        console.log(authorities)
        const hrsList = await EmployeeRepo.getAllIfExists({department: { $in: [...hrRoles]}})
        let hrMailers = hrsList.map(e=>e.email)
        console.log([...mailers,...hrMailers])
        mailers = [...mailers,...hrMailers]
        return res.status(200).json({success:true,message:"Role Retrieved and Mailers array formed!",role:role.roleName,mailIds:mailers,result:[]})
    }
    catch(err){
        console.log(err)
        return res.status(200).json({success:false,message:"Something went wrong!",result:[]})
    }
}

