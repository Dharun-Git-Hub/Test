import { departments } from "../constants/constants.js";
import { addNewDepartment, initializeCounter } from "../repository/department.js";
import { seedRole } from "../repository/employee.js";
import { seedMailFormats } from "../repository/mail.js";

export const seedRolesAndMappings = async () => {
    try {
        console.log("Starting role and mapping seeding...");
        const rolesData = [
            {
                roleName: "Management",
                permissions: { create: true, read: true, update: true, delete: true },
            },
            {
                roleName: "Leader",
                permissions: { create: false, read: true, update: true, delete: false },
            },
            {
                roleName: "Employee",
                permissions: { create: false, read: true, update: false, delete: false },
            },
            {
                roleName: "HR",
                permissions: { create: true, read: true, update: true, delete: true },
            }
        ];

        const roleDocs = {};
        for (const role of rolesData) {
            const doc = await seedRole(role)
            roleDocs[role.roleName] = doc;
        }
        let defaultDepartments = departments
        for(const i of defaultDepartments){
            try{
                await addNewDepartment(i)
            }
            catch(err){
                console.log(err)
            }
        }
        await initializeCounter()
        await seedMailFormats()
    }
    catch (err) {
        console.log(err);
    }
};
