import express from 'express'
import cors from 'cors'
import router from './app/routes/index.js'
import { connectToDatabase } from './config/db.js'
import { loadDepartments } from './app/repository/department.js'
import cookieParser from 'cookie-parser'

const app = express()
const PORT = 3000

app.use(express.json())
app.use(cors())
app.use(cookieParser())
app.use(router)

const startServer = async () => {
    try {
        await connectToDatabase()
        await loadDepartments()
        app.listen(PORT, () => {
            console.log(`Server Initiated @Port: ${PORT}`)
        })
    }
    catch (err) {
        console.log(err)
    }
}

startServer()

