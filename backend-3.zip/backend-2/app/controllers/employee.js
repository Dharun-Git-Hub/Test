import * as EmployeeService from "../services/employee.service.js";

export const addEmployee = async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      employeeId,
      email,
      phone,
      department,
      specialRole,
      assignees
    } = req.body;

    const newEmployee = await EmployeeService.createEmployee({
      firstName,
      lastName,
      employeeId,
      email,
      phone,
      department,
      specialRole,
      assignees
    });

    return res.status(200).json({
      success: true,
      message: "Employee created successfully",
      result: newEmployee
    });
  } catch (err) {
    console.error("Error adding employee:", err);
    return res.status(200).json({
      success: false,
      message: "Something went wrong!",
      result: []
    });
  }
}

export const updateEmployee = async (req, res) => {
  try {
    const {
      id,
      firstName,
      lastName,
      email,
      phone,
      department,
      specialRole,
      assignees
    } = req.body;

    // --- 2️⃣ Build dynamic update object ---
    const updatedData = {};

    if (firstName !== undefined) updatedData.firstName = firstName;
    if (lastName !== undefined) updatedData.lastName = lastName;
    if (email !== undefined) updatedData.email = email;
    if (phone !== undefined) updatedData.phone = phone;
    if (department !== undefined) updatedData.department = department;
    if (specialRole !== undefined) updatedData.specialRole = specialRole;
    if (assignees !== undefined) updatedData.assignees = assignees;

    // --- 3️⃣ Ensure at least one field to update ---
    if (Object.keys(updatedData).length === 0) {
      return res.status(400).json({
        success: false,
        message: "No fields provided for update",
        result: []
      });
    }

    // --- 4️⃣ Update employee via service ---
    const updatedEmployee = await EmployeeService.updateEmployeeById(id, updatedData);

    // --- 5️⃣ Handle not found ---
    if (!updatedEmployee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
        result: []
      });
    }

    // --- 6️⃣ Success response ---
    return res.status(200).json({
      success: true,
      message: "Employee updated successfully",
      result: updatedEmployee
    });

  } catch (err) {
    console.error("Error updating employee:", err);
    return res.status(500).json({
      success: false,
      message: "Something went wrong!",
      result: []
    });
  }
};

export const deleteEmployee = async (req, res) => {
  try {
    const { id } = req.body; // employee ID from URL

    // 2️⃣ Call service to delete
    const deletedEmployee = await EmployeeService.deleteEmployeeById(id);

    // 3️⃣ Handle "not found"
    if (!deletedEmployee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
        result: []
      });
    }

    // 4️⃣ Success
    return res.status(200).json({
      success: true,
      message: "Employee deleted successfully",
      result: deletedEmployee
    });

  } catch (err) {
    console.error("Error deleting employee:", err);
    return res.status(500).json({
      success: false,
      message: "Something went wrong!",
      result: []
    });
  }
};

export const getAllEmployees = async (req, res) => {
    try {
        // optional filters from query params (like ?department=123)
        const filter = {}
        const list = await EmployeeService.getAllEmployeesList(filter)

        return res.status(200).json({
            success: true,
            message: "Employees retrieved successfully!",
            result: list, // ✅ Use `result` instead of returning an empty array
        });
    } catch (err) {
        console.error("Error while retrieving employees:", err);
        return res.status(500).json({
            success: false,
            message: "Something went wrong!",
            result: [],
        });
    }
};
