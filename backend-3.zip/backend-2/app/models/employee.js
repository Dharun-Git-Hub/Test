import mongoose from "mongoose";
import bcrypt from "bcrypt";

const employeeSchema = new mongoose.Schema({
  firstName: { type: String, required: true, trim: true },
  lastName: { type: String, trim: true, default: "" },
  employeeId: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phone: { type: String, required: true },
  
  // Department: references Role model
  department: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "Role",
    required: true 
  },

  // Special Role: references subRole _id inside a Role document
  specialRole: { 
    type: mongoose.Schema.Types.ObjectId,
    default: null 
  },

  dateOfJoining: { type: Date, default: Date.now },

  // Assignees: references other employees
  assignees: [{ type: mongoose.Schema.Types.ObjectId, ref: "Employee" }]
});

export const Employee = mongoose.model("Employee", employeeSchema);

employeeSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});
