import { Employee } from "../models/employee.js";

export const createEmployee = async (details) => {
    try {
        details.password = "000"
        const employee = await Employee.create(details);
        return employee;
    } catch (err) {
        console.error("Error creating employee:", err);
        throw err;
    }
};

export const updateEmployeeById = async (id, updatedData) => {
    try {
        const employee = await Employee.findByIdAndUpdate(
            id,
            { $set: updatedData },
            { new: true, runValidators: true } // returns updated doc, validates schema
        );
        return employee;
    } catch (err) {
        console.error("Error in updateEmployeeById:", err);
        throw err;
    }
};

export const deleteEmployeeById = async (id) => {
    try {
        // deleteOne returns { deletedCount: X }, not the doc itself.
        const deletedEmployee = await Employee.findByIdAndDelete(id);
        return deletedEmployee; // null if not found
    } catch (err) {
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
};

export const getAllEmployeesList = async (filter) => {
    try{
        const list = await Employee.find(filter)
        return list
    }
    catch(err){
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
}