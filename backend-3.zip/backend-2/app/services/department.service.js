import { Role, SubRole } from "../models/role.js";

export const addDepartments = async (departments) => {
  try {
    if (!Array.isArray(departments) || departments.length === 0) {
      throw new Error("Departments must be a non-empty array");
    }

    const insertedOrUpdated = [];

    for (const roleName of departments) {
      // Update if exists, insert if not
      const result = await Role.updateOne(
        { roleName },              // filter by roleName
        { $setOnInsert: { roleName, subRoles: [] } }, // only set if inserting
        { upsert: true }           // create if not exists
      );

      insertedOrUpdated.push({ roleName, result });
    }

    return insertedOrUpdated;
  } catch (err) {
    console.error("Error adding departments:", err);
    throw err;
  }
};

export const loadSubRoles = async (subRoles) => {
  try{
  if (!Array.isArray(subRoles) || subRoles.length === 0) {
      throw new Error("subRoles must be a non-empty array");
    }

    const insertedOrUpdated = [];

    for (const name of subRoles) {
      // Update if exists, insert if not
      const result = await SubRole.updateOne(
        { name },              // filter by roleName
        { $setOnInsert: {name} }, // only set if inserting
        { upsert: true }           // create if not exists
      );

      insertedOrUpdated.push({ name, result });
    }

    return insertedOrUpdated;
  } catch (err) {
    console.error("Error adding departments:", err);
    throw err;
  }
}