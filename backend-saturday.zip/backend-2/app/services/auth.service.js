import { Permission } from "../models/permission.js"

export const getAuthIdByName = async (authType) => {
    try{
        const details = await Permission.findOne({authType})
        return details
    }
    catch(err){
        console.log(err)
        throw err
    }
}

export const getAuthDetailsById = async (authLogType) => {
    try{
        const details = await Permission.findById(authLogType)
        return details
    }
    catch(err){
        console.log(err)
        throw err
    }
}