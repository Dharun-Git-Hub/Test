import { decryptData, hrsId, managersId, nofifyWithEmail, tlsId } from "../helper/helper.js";
import { Employee } from "../models/employee.js";
import { Leave } from "../models/leave.js";
import { Personal } from '../models/personal.js'
import { Role, SubRole } from "../models/role.js";
import bcrypt from 'bcrypt'

export const createEmployee = async (details) => {
    try {
        details.password = await bcrypt.hash("000", 10)
        if ((await Employee.countDocuments()) === 0) {
            details.employeeId = "FC" + (0o0 + (1).toString().padStart(3, '0'));
            details.employeeNumber = 1
        }
        else {
            const lastNumber = await Employee.findOne().sort({ _id: -1 }).limit(1)
            console.log(lastNumber)
            details.employeeNumber = lastNumber.employeeNumber + 1;
            console.log("EMPLOYEE NUMBER : ", lastNumber.employeeNumber)
            details.employeeId = "FC" + (0o0 + (details.employeeNumber).toString().padStart(3, '0'));
        }
        const employee = await Employee.create(details);
        await Personal.create({ employeeId: employee._id });
        console.log('Personal Space Created!')
        return employee;
    } catch (err) {
        console.error("Error creating employee:", err);
        throw err;
    }
};

export const updateEmployeeById = async (id, updatedData) => {
    try {
        const employee = await Employee.findByIdAndUpdate(
            id,
            { $set: updatedData },
            { new: true, runValidators: true }
        );
        return employee;
    } catch (err) {
        console.error("Error in updateEmployeeById:", err);
        throw err;
    }
};

export const editEmployeePersonals = async (id, updatedData) => {
    try {
        console.log(updatedData)
        const found = await Personal.findOne({ employeeId: id })
        console.log(found)
        await Personal.findOneAndUpdate(
            { employeeId: id },
            { $set: updatedData },
            { new: true, runValidators: true }
        );
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const deleteEmployeeById = async (id) => {
    try {
        const deletedEmployee = await Employee.findByIdAndDelete(id);
        await Personal.deleteOne({ employeeId: id });
        return deletedEmployee;
    } catch (err) {
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
};

export const getAllEmployeesList = async (filter) => {
    try {
        const list = await Employee.find(filter)
        console.log(list)
        return list
    }
    catch (err) {
        console.error("Error in deleteEmployeeById:", err);
        throw err;
    }
}

export const findEmployeeByIdAssignees = async (id) => {
    try {
        const details = await Employee.findById(id)
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeeIfExists = async (filter) => {
    try {
        const details = await Employee.findOne(filter)
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getManagersList = async () => {
    try {
        const manager = await managersId()
        const data = await Employee.find({ specialRole: manager }).populate("department").select("-password")
        console.log("Managers: ", data)
        if (data) {
            let temp = []
            for (const i of data) {
                let dtls = {
                    name: i.firstName + " " + i.lastName,
                    email: i.email,
                    department: i.department.roleName
                }
                temp.push(dtls)
            }
            return temp
        }
        return data
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getTlsList = async () => {
    try {
        const tl = await tlsId()
        const data = await Employee.find({ specialRole: tl }).populate("department").select("-password")
        console.log("TLs: ", data)
        if (data) {
            let temp = []
            for (const i of data) {
                let dtls = {
                    name: i.firstName + " " + i.lastName,
                    email: i.email,
                    department: i.department.roleName
                }
                temp.push(dtls)
            }
            return temp
        }
        return data
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeeById = async (id) => {
    try {
        const details = await Employee.findById(id)
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeeByIdDeployed = async (id) => {
    try {
        const details = await Employee.findById(id).populate('department').lean();
        if (!details) throw new Error("Employee not found");
        const specialRoleDtls = await SubRole.findById(details.specialRole).lean();
        const result = {
            ...details,
            specialRole: specialRoleDtls
        };
        return result;
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const getEmployeeByIdSecurely = async (id) => {
    try {
        const details = await Employee.findById(id).select("-password")
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getEmployeePersonals = async (id) => {
    try {
        const details = await Personal.findOne({ employeeId: id })
        return details
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getLeaveFormById = async (id) => {
    try {
        const form = await Leave.findById(id)
        return form
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getPendingForms = async (id, email) => {
    try {
        const form = await Leave.findOne({
            _id: id,
            authorities: { $in: [email] },
            signed: { $not: { $in: [email] } }
        });
        return form
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const getAllForms = async (id, email) => {
    try {
        const form = await Leave.findOne({
            _id: id,
            authorities: { $in: [email] },
        });
        return form
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const findHrs = async () => {
    try {
        const hr = await hrsId()
        console.log(hr)
        const list = await Employee.find({ department: hr })
        console.log("LIST OF HR MAILS: ", list)
        return list.map(e => e.email)
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const createLeaveForm = async (subject, reason, fromDate, toDate, fromTime, toTime, mails) => {
    try {
        const leaveForm = await Leave.create({
            subject,
            mailData: reason,
            fromDate,
            toDate: subject === "PERMISSION" ? fromDate : toDate,
            fromTime: subject === "PERMISSION" ? fromTime : new Date(fromDate),
            toTime: subject === "PERMISSION" ? toTime : fromTime,
            approved: false,
            authorities: mails,
            signed: []
        })
        console.log(leaveForm)
        return leaveForm
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const updateEmployeeLeave = async (_id, leaveForm) => {
    try {
        await Employee.findByIdAndUpdate(
            _id,
            { $push: { leaves: leaveForm._id } },
            { new: true, useFindAndModify: false }
        );
    }
    catch (err) {
        console.log(err)
        throw err
    }
}

export const findManagerId = async () => {
    const id = await SubRole.findOne({ name: "Manager" })
    if (id)
        return id._id
    return id
}

export const findTlId = async () => {
    const id = await SubRole.findOne({ name: "TL" })
    if (id)
        return id._id
    return id
}

export const findHrId = async () => {
    const id = await Role.findOne({ roleName: "HR" })
    console.log(id)
    if (id)
        return id._id
    return id
}

export const updateLeaveForm = async (id, filter) => {
    try {
        const updated = await Leave.findByIdAndUpdate(id, filter, { new: true });
        if (!updated) {
            console.log("No leave form found with the given ID");
            return null;
        }
        const fullyApproved = updated.authorities.every(a => updated.signed.includes(a));
        if (fullyApproved) {
            const employeeDetails = await getEmployeeIfExists({ leaves: { $in: id } })
            console.log(employeeDetails)
            updated.approved = true;
            await updated.save();
            const details = {
                myEmail: employeeDetails.email,
                conf: decryptData(employeeDetails.conf),
                toMail: employeeDetails.email,
                subject: `${updated.subject} Approved!`,
                htmlBody: `<p> Hello, ${employeeDetails.firstName + " " + employeeDetails.lastName}</p>
                <p>This is to let you know that,</p>
                <p>Your Request for ${updated.subject} is just now approved!</p>
                <p>Ref: ${updated._id}</p>
                <p>Thank you!</p>`
            }
            await nofifyWithEmail(details)
        }
        return updated;
    } catch (err) {
        console.error("updateLeaveForm error:", err);
        throw err;
    }
};


export const rejectThisRequest = async (leaveId, id, email) => {
    try {
        const updated = await Leave.findByIdAndUpdate(
            leaveId,
            {
                $push: { rejected: id },
                $set: { approved: false },
                $pull: { signed: email }
            },
            { new: true }
        );

        const empDetails = await getEmployeeIfExists({ leaves: { $in: leaveId } });
        const rejectorDtls = await getEmployeeById(id);
        const specialRole = rejectorDtls.specialRole
            ? ((await SubRole.findById(rejectorDtls.specialRole)).name + " of ")
            : "";
        const department = (await Role.findById(rejectorDtls.department)).roleName;

        const details = {
            myEmail: rejectorDtls.email,
            conf: decryptData(rejectorDtls.conf),
            toMail: empDetails.email,
            subject: `${updated.subject} Rejected!`,
            htmlBody: `
        <p>Hello, ${empDetails.firstName} ${empDetails.lastName}</p>
        <p>This is to let you know that,</p>
        <p>Your request for ${updated.subject} has just been rejected by
        ${rejectorDtls.firstName} ${rejectorDtls.lastName} - ${specialRole}${department} Department!</p>
        <p>Ref: ${updated._id}</p>
        <p>Thank you!</p>
      `
        };

        await nofifyWithEmail(details);
        return updated;
    } catch (err) {
        console.log(err);
        throw err;
    }
};


export const revertThisRejection = async (leaveId, id) => {
    try {
        const updated = await Leave.findById(leaveId);
        await Leave.updateOne(
            { _id: leaveId },
            { $pull: { rejected: id } }
        );
        if (updated.rejected.length === 0) {
            const fullyApproved = updated.authorities.every(a => updated.signed.includes(a));
            if (fullyApproved) {
                updated.approved = true
                await updated.save()
            }
        }
        else {
            await updated.save()
        }
        const empDetails = await getEmployeeIfExists({ leaves: { $in: leaveId } })
        const rejectorDtls = await getEmployeeById(id)
        const specialRole = rejectorDtls.specialRole ? ((await SubRole.findById(rejectorDtls.specialRole)).name + " of ") : ""
        const department = (await Role.findById(rejectorDtls.department)).roleName
        const details = {
            myEmail: rejectorDtls.email,
            conf: decryptData(rejectorDtls.conf),
            toMail: empDetails.email,
            subject: `${updated.subject} Rejection REVERTED!`,
            htmlBody: `<p> Hello, ${empDetails.firstName + " " + empDetails.lastName}</p>
                <p>This is to let you know that,</p>
                <p>Your Request for ${updated.subject} is just now activated by ${rejectorDtls.firstName + " " + rejectorDtls.lastName} - ${specialRole}${department} Department!</p>
                <p>Ref: ${updated._id}</p>
                <p>Thank you!</p>`
        }
        await nofifyWithEmail(details)
        return updated
    }
    catch (err) {
        console.log(err)
        throw err
    }
}