import * as Helpers from "../helper/helper.js"
import Admin from "../models/admin.js"

export const initiateAdmin = async () => {
    try{
        const details = {
            userName: Helpers.encryptAdmin('ADMIN123'),
            email: 'admin@gmail.com',
            password: Helpers.encryptAdmin('admin@123'),
            role: 'admin'
        }
        if((await Admin.countDocuments()===0))
            await Admin.create(details)
    }
    catch(err){
        console.log(err)
        throw err
    }
}

export const isAdmin = async (userName,email,password) => {
    try{
        const dbAdmin = await Admin.findOne({email})
        if(!dbAdmin)
            return false
        const userNameMatches = userName === Helpers.decryptAdmin(dbAdmin.userName)
        if(!userNameMatches)
            return false
        const passwordMatches = password === Helpers.decryptAdmin(dbAdmin.password)
        if(!passwordMatches)
            return false
        return dbAdmin
    }   
    catch(err){
        console.log(err)
        throw err
    }
}