// export const authorizeRole = (...allowedRoles) => {
//   return (req, res, next) => {
//     const roleName = req.user?.department?.roleName;
//     const subRoleName = req.user?.specialRole?.name || "Employee"
//     console.log(roleName)
//     console.log(subRoleName)
//     if (req.user.role && allowedRoles.includes((req.user?.role).toUpperCase()))
//       return next()

//     if (!allowedRoles.includes(roleName) && !allowedRoles.includes(subRoleName)) {
//       return res.status(200).json({
//         success: false, message: "Forbidden. You do not have the required role.", result: [],
//       });
//     }
//     next();
//   };
// };

export const authorizeRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.authLogType)
      return res.status(403).json({ success: false, message: "Forbidden. No auth information provided.", result: [] })

    const [operation, resource] = allowedRoles
    if (!req.authLogType[operation])
      return res.status(403).json({ success: false, message: `Forbidden. Operation '${operation}' not allowed.`, result: [] })

    const hasAccess = req.authLogType[operation].includes(resource)
    console.log(`Checking ${operation} permission for '${resource}':`, hasAccess)
    if (!hasAccess) 
      return res.status(403).json({ success: false, message: `Forbidden. You don't have permission to ${operation} ${resource}.`, result: [] })
    next()
  }
}


// const authorizeRole = (...allowedRoles) => {
//     return (req, res, next) => {
//         const userRole = req.user.authlogtype;
//         if (!allowedRoles.includes(userRole)) {
//             return res.status(200).json({ success: false, message: 'Forbidden. You do not have the required role.', result: [] })
//         }
//         next();
//     };
// };

// export default authorizeRole;