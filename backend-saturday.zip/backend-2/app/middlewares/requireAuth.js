import jwt from "jsonwebtoken";
import { Employee } from "../models/employee.js";
import { SubRole } from "../models/role.js";
import Admin from "../models/admin.js";
import { getAuthDetailsById } from "../services/auth.service.js";

export const requireAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith("Bearer ")) 
            return res.status(401).json({ message: "No token provided" })

        const token = authHeader.split(" ")[1];
        const decoded = jwt.verify(token, "JWT_SECRET");
        console.log("DECODED: ",decoded)
        let employee = await Employee.findById(decoded.id).populate("department");
        let authLogType = decoded.authLogType
        if (!employee) {
            employee = await Admin.findById(decoded.id)
            if (!employee)
                return res.status(200).json({ success: false, message: "User not found", result: [] });
        }

        if (employee.specialRole) {
            let specialRoleDetails = await SubRole.findById(employee.specialRole);
            let employeeObj = employee.toObject();
            employeeObj.specialRole = specialRoleDetails
            req.user = employeeObj
        }
        else {
            req.user = employee
        }
        req.authLogType = await getAuthDetailsById(authLogType)
        if(!req.authLogType)
            return res.status(200).json({success:false,message:"Role not Found!",result:[]})
        
        console.log("Require Auth: ", req.user)
        console.log(req.authLogType)
        next()

    } catch (error) {
        console.log(error)
        res.status(200).json({ success: false, message: "Invalid or expired token", result: [] });
    }
};
