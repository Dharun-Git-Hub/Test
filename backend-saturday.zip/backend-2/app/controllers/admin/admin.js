import * as AdminServices from "../../services/admin.service.js"
import jwt from 'jsonwebtoken'
import bcrypt from 'bcrypt'
import * as EmployeeService from "../../services/employee.service.js"

export const loginAdmin = async (req, res) => {
    try {
        const { userName, email, password } = req.body
        const verified = await AdminServices.isAdmin(userName, email, password)
        if (!verified)
            return res.status(200).json({ success: false, message: "Invalid Credentials!", result: [] })
        const token = jwt.sign(
            { id: verified._id, role: verified.role },
            "JWT_SECRET",
            { expiresIn: "1h" }
        );
        return res.status(200).json({ success: true, message: "Admin Logged In!", result: [], token })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}

export const changePassword = async (req, res) => {
    try {
        const { id, newPassword, repeatPassword } = req.body
        if (newPassword !== repeatPassword)
            return res.status(200).json({ success: false, message: "New Password & Repeated Password aren't matching!", result: [] })
        const exists = await EmployeeService.getEmployeeById(id)
        if (!exists)
            return res.status(200).json({ success: false, message: "Employee Not Found!", result: [] })
        const hashed = await bcrypt.hash(newPassword, 10)
        await EmployeeService.updateEmployeeById(id, { password: hashed })
        return res.status(200).json({ success: true, message: "Password changed successfully!", result: [] })
    }
    catch (err) {
        console.log(err)
        return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
    }
}