import * as EmployeeService from "../services/employee.service.js";
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import * as DepartmentServices from "../services/department.service.js";
import { createMail, decryptData, encryptData, sendEmail } from "../helper/helper.js";

export const addEmployee = async (req, res) => {
  try {
    const { firstName, conf, lastName, email, phone, department, specialRole, assignees, type } = req.body;
    const authLogType = await getAuthIdByName(type)
    const emailExists = await EmployeeService.getEmployeeIfExists({ email })
    if (emailExists)
      return res.status(200).json({
        success: false, message: "Employee with this email already found!", result: []
      });
    let deptDetails = await DepartmentServices.findDepartmentById(department)
    if (!deptDetails)
      return res.status(200).json({
        success: false, message: "Department Not found!", result: []
      });
    if (assignees.length > 0) {
      for (const id of assignees) {
        let dtls = await EmployeeService.getEmployeeById(id)
        if (!dtls)
          return res.status(200).json({
            success: false, message: `Assignee - ${id} is not found!`, result: []
          });
      }
    }
    const newEmployee = await EmployeeService.createEmployee({ firstName, conf: encryptData(conf), lastName, email, phone, department, specialRole, assignees, type: authLogType._id });
    return res.status(200).json({
      success: true, message: "Employee created successfully!", result: newEmployee
    });
  }
  catch (err) {
    console.error("Error adding employee:", err);
    return res.status(200).json({
      success: false, message: "Something went wrong!", result: []
    });
  }
}

export const updateEmployee = async (req, res) => {
  try {
    const { id, firstName, lastName, email, phone, department, specialRole, assignees } = req.body;
    const updatedData = {};
    if (email !== undefined) {
      const emailExists = await EmployeeService.getEmployeeById(id)
      if (emailExists && emailExists._id.toString() !== id)
        return res.status(200).json({ success: false, message: "This email has been in use by another employee!", result: [] })
    }

    if (firstName !== undefined) updatedData.firstName = firstName;
    if (lastName !== undefined) updatedData.lastName = lastName;
    if (email !== undefined) updatedData.email = email;
    if (phone !== undefined) updatedData.phone = phone;
    if (department !== undefined) updatedData.department = department;
    if (specialRole !== undefined) updatedData.specialRole = specialRole;
    if (assignees !== undefined) updatedData.assignees = assignees;

    if (Object.keys(updatedData).length === 0) {
      return res.status(200).json({
        success: false, message: "No fields provided for update", result: []
      });
    }

    const updatedEmployee = await EmployeeService.updateEmployeeById(id, updatedData);

    if (!updatedEmployee) {
      return res.status(200).json({
        success: false, message: "Employee not found", result: []
      });
    }

    return res.status(200).json({
      success: true,
      message: "Employee updated successfully",
      result: updatedEmployee
    });

  } catch (err) {
    console.error("Error updating employee:", err);
    return res.status(200).json({
      success: false,
      message: "Something went wrong!",
      result: []
    });
  }
};

export const deleteEmployee = async (req, res) => {
  try {
    const { id } = req.body;
    const employeeExists = await EmployeeService.getEmployeeById(id)
    if (!employeeExists)
      return res.status(200).json({
        success: false, message: "Employee not found!", result: []
      });

    const deletedEmployee = await EmployeeService.deleteEmployeeById(id);
    if (!deletedEmployee) {
      return res.status(200).json({
        success: false,
        message: "Employee not found",
        result: []
      });
    }

    return res.status(200).json({
      success: true,
      message: "Employee deleted successfully",
      result: deletedEmployee
    });

  } catch (err) {
    console.error("Error deleting employee:", err);
    return res.status(200).json({
      success: false,
      message: "Something went wrong!",
      result: []
    });
  }
};

export const getAllEmployees = async (req, res) => {
  try {
    const filter = {}
    const list = await EmployeeService.getAllEmployeesList(filter)
    let additionals = {
      noOfEmployees: list?.length,
    }

    return res.status(200).json({
      success: true,
      message: "Employees retrieved successfully!",
      result: list,
      additionals
    });
  } catch (err) {
    console.error("Error while retrieving employees:", err);
    return res.status(200).json({
      success: false,
      message: "Something went wrong!",
      result: [],
    });
  }
};

export const loginEmployee = async (req, res) => {
  try {
    const { email, password } = req.body;

    const emailExists = await EmployeeService.getEmployeeIfExists({ email })
    if (!emailExists)
      return res.status(200).json({
        success: false, message: "Employee not found!", result: []
      });
    const employee = emailExists
    const isPasswordValid = await bcrypt.compare(password, employee.password);
    if (!isPasswordValid) {
      return res.status(200).json({ success: false, message: "Invalid credentials", result: [] });
    }

    const roleNamed = await DepartmentServices.getRoleNameById(employee.department);
    const roleName = roleNamed?.roleName || "Unknown";

    const token = jwt.sign(
      { id: employee._id, role: roleName, authLogType: employee.type },
      "JWT_SECRET",
      { expiresIn: "7d" }
    );

    res.status(200).json({
      success: true,
      message: "Login successful",
      token,
      employee: {
        id: employee._id,
        name: `${employee.firstName} ${employee.lastName}`,
        email: employee.email,
        department: roleName,
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(200).json({ success: false, message: "Server error", error: error.message, result: [] });
  }
};

export const askForPermission = async (req, res) => {
  try {
    const { _id } = req.user;
    const { subject, reason, fromDate, toDate, fromTime, toTime } = req.body;

    if (!fromDate)
      return res.status(200).json({ success: false, message: "Date should not be empty!", result: [] });

    const validFromDate = new Date(fromDate) > new Date();
    const validToDate = new Date(toDate) > new Date() && new Date(toDate) >= new Date(fromDate);

    if (!validFromDate)
      return res.status(200).json({ success: false, message: "From Date should be in the future!", result: [] });

    if (!validToDate)
      return res.status(200).json({ success: false, message: "To Date should be in the future!", result: [] });

    if (subject === "PERMISSION" && (!fromTime || !toTime)) {
      return res.status(200).json({ success: false, message: "From and To Times should be mentioned for a permission!", result: [] });
    }

    if (subject === "LEAVE" && (!fromDate || !toDate)) {
      return res.status(200).json({ success: false, message: "From and To Dates should be mentioned for a leave!", result: [] });
    }

    const myName = `${req.user.firstName} ${req.user.lastName || ""}`;
    const employeeId = req.user.employeeId;
    const department = req.user.department.roleName;
    const specialRole = req.user.specialRole?.name || "Employee";

    if (!_id) {
      return res.status(200).json({ success: false, message: "Employee id is required", result: [] });
    }

    const employees = await EmployeeService.findEmployeeByIdAssignees(_id);
    if (!employees) {
      return res.status(200).json({ success: false, message: "No Such Employee Found!!", result: [] });
    }

    const assignees = await Promise.all(
      employees.assignees.map(async (id) => await EmployeeService.getEmployeeByIdDeployed(id))
    );

    const assigneeMails = assignees.map(e => e.email);
    const hrList = await EmployeeService.findHrs();

    let date, time;
    if (subject === "LEAVE") {
      date = [fromDate, toDate];
      time = "";
    } else if (subject === "PERMISSION") {
      date = [fromDate];
      time = [fromTime, toTime];
    }

    const hrMailContent = createMail(
      subject,
      date,
      time,
      reason,
      "HR & Approvers",
      specialRole,
      subject,
      employeeId,
      myName,
      department
    );

    await sendEmail({
      myEmail: req.user.email,
      conf: decryptData(req.user.conf),
      toMail: hrList,
      ccMail: assigneeMails,
      subject: hrMailContent.subject,
      htmlBody: hrMailContent.htmlBody
    });

    const leaveForm = await EmployeeService.createLeaveForm(subject, reason, fromDate, toDate, fromTime, toTime, [...hrList, ...assigneeMails])
    await EmployeeService.updateEmployeeLeave(_id, leaveForm)

    res.status(200).json({ success: true, message: "Mail sent successfully", data: { to: hrList, cc: assigneeMails } });
  } catch (error) {
    console.error("askFor error:", error);
    res.status(200).json({ success: false, message: "Server error", error: error.message, result: [] });
  }
};


export const managersList = async (req, res) => {
  try {
    const list = await EmployeeService.getManagersList()
    return res.status(200).json({ success: true, message: "Retrieved Managers!", list, result: [] })
  }
  catch (err) {
    console.log(err)
    res.status(200).json({ success: false, message: "Server error", error: err.message, result: [] });
  }
}

export const tlsList = async (req, res) => {
  try {
    const list = await EmployeeService.getTlsList()
    return res.status(200).json({ success: true, message: "Retrieved TLs!", list, result: [] })
  }
  catch (err) {
    console.log(err)
    res.status(200).json({ success: false, message: "Server error", error: err.message, result: [] });
  }
}

export const requestChangePassword = async (req, res) => {
  try {
    const { employeeId, email } = req.body
    const emailExists = await EmployeeService.getEmployeeIfExists({ email })
    if (!emailExists)
      return res.status(200).json({
        success: false, message: "Employee not found!", result: []
      });
    const details = await EmployeeService.getEmployeeIfExists({ email })
    if (!details)
      return res.status(200).json({ success: false, message: "User Not Found!", result: [] })
    if (details.employeeId === employeeId && details.email === email)
      return res.status(200).json({ success: true, message: "Authorized!", id: details._id, result: [] })
    return res.status(200).json({ success: false, message: "Un-Authorized!", result: [] })
  }
  catch (err) {
    console.log(err)
    res.status(200).json({ success: false, message: "Server error", error: err.message, result: [] });
  }
}

export const changePassword = async (req, res) => {
  try {
    const { id, assignedPassword, newPassword, repeatPassword } = req.body
    const exists = await EmployeeService.getEmployeeById(id)
    if (!exists)
      return res.status(200).json({ success: false, message: "Employee Details Not Found!", result: [] })
    const check = await bcrypt.compare(assignedPassword, exists.password)
    if (!check)
      return res.status(200).json({ success: false, message: "Incorrect Assigned Password!", result: [] })
    if (newPassword !== repeatPassword)
      return res.status(200).json({ success: false, message: "Passwords Won't Match!", result: [] })
    if ((await bcrypt.compare(newPassword, exists.password)))
      return res.status(200).json({ success: false, message: "New Password should not be as same as Old Password!", result: [] })
    const hashed = await bcrypt.hash(newPassword, 10)
    await EmployeeService.updateEmployeeById(id, { password: hashed })
    return res.status(200).json({ success: true, message: "Password Changed Successfully!", result: [] })
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
  }
}

export const editPersonalDetails = async (req, res) => {
  try {
    const { id } = req.body
    if (!id)
      return res.status(200).json({ success: false, message: "Employee id is required", result: [] })
    const { address, additionalPhoneNumber, sslcPercentage, sslcSchool, hsePercentage, hseSchool, graduatePercentage, graduateCollegeName, graduateCollegeAddress, graduateYearOfPassedOut, graduateBacklogs, dateOfBirth, panNumber, aadharNumber, accNo, salary, martialStatus, currentState } = req.body;
    const updatedData = {
      profile: {},
      academics: {
        sslc: {},
        hse: {},
        graduation: {},
      },
      documents: {
        pan: {},
        aadhar: {},
        bank: {},
      },
      experience: [],
    };


    if (address !== undefined) updatedData.profile.address = address;
    if (additionalPhoneNumber !== undefined) updatedData.profile.additionalPhoneNumber = additionalPhoneNumber;
    if (sslcPercentage !== undefined) updatedData.academics.sslc.sslcPercentage = sslcPercentage;
    if (sslcSchool !== undefined) updatedData.academics.sslc.sslcSchool = sslcSchool;
    if (hsePercentage !== undefined) updatedData.academics.hse.hsePercentage = hsePercentage;
    if (hseSchool !== undefined) updatedData.academics.hse.hseSchool = hseSchool;
    if (graduatePercentage !== undefined) updatedData.academics.graduation.graduatePercentage = graduatePercentage;
    if (graduateCollegeName !== undefined) updatedData.academics.graduation.graduateCollegeName = graduateCollegeName;
    if (graduateCollegeAddress !== undefined) updatedData.academics.graduation.graduateCollegeAddress = graduateCollegeAddress;
    if (graduateYearOfPassedOut !== undefined) updatedData.academics.graduation.graduateYearOfPassedOut = graduateYearOfPassedOut;
    if (graduateBacklogs !== undefined) updatedData.academics.graduation.graduateBacklogs = graduateBacklogs;
    if (dateOfBirth !== undefined) updatedData.profile.dateOfBirth = dateOfBirth;
    if (panNumber !== undefined) updatedData.documents.pan.panNumber = panNumber
    if (aadharNumber !== undefined) updatedData.documents.aadhar.aadharNumber = aadharNumber
    if (accNo !== undefined) updatedData.documents.bank.accNo = accNo
    if (salary !== undefined) updatedData.profile.salary = salary
    if (martialStatus !== undefined) updatedData.profile.martialStatus = martialStatus
    if (currentState !== undefined) updatedData.profile.currentState = currentState


    if (Object.keys(updatedData).length === 0) {
      return res.status(200).json({
        success: false, message: "No fields provided for update", result: []
      });
    }
    console.log(updatedData)
    await EmployeeService.editEmployeePersonals(id, updatedData)

    return res.status(200).json({
      success: true,
      message: "Employee updated successfully",
      result: []
    })
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
  }
}

export const getMyDetails = async (req, res) => {
  try {
    const id = req.user?._id;
    if (!id)
      return res.status(200).json({ success: false, message: "Employee id is required", result: [] })
    let employeeDetails;
    const empDetails = await EmployeeService.getEmployeeByIdSecurely(id)
    const personalDetails = await EmployeeService.getEmployeePersonals(id)
    console.log("EMPLOYEE DTLS: ", empDetails)
    console.log("PERSONAL DTLS: ", personalDetails)
    employeeDetails = {
      empDetails,
      personalDetails
    }
    return res.status(200).json({ success: true, message: "Your Details Prepared!", result: employeeDetails })
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
  }
}

export const getLeaveForms = async (req, res) => {
  try {
    const employees = await EmployeeService.getAllEmployeesList({})
    let forms = []
    for (const employee of employees) {
      console.log(employee)
      if (employee.leaves?.length > 0) {
        for (const leaveId of employee.leaves) {
          console.log(leaveId)
          forms.push((await EmployeeService.getLeaveFormById(leaveId)))
        }
      }
    }
    return res.status(200).json({ success: true, message: "Leave Forms Retrieved!", result: forms })
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
  }
}

export const getPendingRequests = async (req, res) => {
  try {
    const id = req.user?._id
    if (!id)
      return res.status(200).json({ success: false, message: "Employee id is required!", result: [] })
    const employees = await EmployeeService.getAllEmployeesList({})
    let forms = []
    for (const employee of employees) {
      console.log(employee)
      if (employee.leaves?.length > 0) {
        for (const leaveId of employee.leaves) {
          console.log(leaveId)
          let form = await EmployeeService.getPendingForms(leaveId, req.user.email)
          if (form)
            forms.push(form)
        }
      }
    }
    return res.status(200).json({ success: true, message: "Leave Forms Retrieved!", result: forms })
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
  }
}

export const getAllPermissionForms = async (req, res) => {
  try {
    const id = req.user?._id
    if (!id)
      return res.status(200).json({ success: false, message: "Employee id is required!", result: [] })
    const employees = await EmployeeService.getAllEmployeesList({})
    let forms = []
    for (const employee of employees) {
      console.log(employee)
      if (employee.leaves?.length > 0) {
        for (const leaveId of employee.leaves) {
          console.log(leaveId)
          let form = await EmployeeService.getAllForms(leaveId, req.user.email)
          if (form)
            forms.push(form)
        }
      }
    }
    return res.status(200).json({ success: true, message: "Leave Forms Retrieved!", result: forms })
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] })
  }
}

import { Leave } from "../models/leave.js";
import { getAuthIdByName } from "../services/auth.service.js";

export const checkToMonthLeave = async (req, res) => {
  try {
    const { _id, leaves } = req.user;

    if (!_id) {
      return res.status(200).json({ success: false, message: "User not found!", result: [] });
    }

    if (!leaves || leaves.length === 0) {
      return res.status(200).json({ success: false, message: "No leaves found for this user!", result: [] });
    }

    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

    let monthLeaves = [];
    let count = 0;

    for (const leaveId of leaves) {
      const leaveDoc = await Leave.findById(leaveId);
      if (!leaveDoc) continue;

      const fromDate = new Date(leaveDoc.fromDate);

      if (fromDate >= firstDay && fromDate <= lastDay) {
        count++;
        monthLeaves.push(leaveDoc);
      }
    }

    let approvedCount = 0;

    monthLeaves.forEach((e) => {
      if (e.approved)
        approvedCount++;
    })

    console.log("This month's leaves:", monthLeaves);
    console.log("This month's leave count:", count);

    return res.status(200).json({
      success: true,
      message: "Fetched this month's leaves successfully!",
      toMonthCount: count,
      approvedToMonth: approvedCount,
      allowedLeaveCount: 2 - count < 0 ? 0 : 2 - count,
      result: monthLeaves
    });

  } catch (err) {
    console.log("checkToMonthLeave error:", err);
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] });
  }
};

export const approvePermission = async (req, res) => {
  try {
    const id = req.user?._id
    if (!id) {
      return res.status(200).json({ success: false, message: "User not found!", result: [] });
    }
    const { leaveId } = req.body
    const leaveDetails = await EmployeeService.getLeaveFormById(leaveId)
    if (!leaveDetails)
      return res.status(200).json({ success: false, message: "Leave Form Not Found!", result: [] });
    if (!leaveDetails.authorities.includes(req.user.email))
      return res.status(200).json({ success: false, message: "You are not an authority to approve this!", result: [] });
    for(let entry of leaveDetails.rejected){
      if(entry.toString() === id.toString()){
        return res.status(200).json({ success: false, message: "You have already rejected this form. Please revert it to approve!", result: [] });
      }
    }
    if (leaveDetails.signed.includes(req.user.email))
      return res.status(200).json({ success: false, message: "You have already approved this form!", result: [] });
    if (leaveDetails.rejected.length !== 0)
      return res.status(200).json({ success: false, message: `This request has already been Rejected!`, result: [] });
    const filter = {
      $push: {
        signed: req.user.email
      }
    }
    const updated = await EmployeeService.updateLeaveForm(leaveId, filter)
    if (!updated)
      return res.status(200).json({ success: false, message: "Leave Form not found!", result: [] });
    return res.status(200).json({ success: true, message: "Form Approved Successfully!", result: [] });
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] });
  }
}

export const rejectRequest = async (req, res) => {
  try {
    const id = req.user?._id
    if (!id) {
      return res.status(200).json({ success: false, message: "User not found!", result: [] });
    }
    const { leaveId } = req.body
    const leaveDetails = await EmployeeService.getLeaveFormById(leaveId)
    if (!leaveDetails)
      return res.status(200).json({ success: false, message: "Leave Form Not Found!", result: [] });
    if (!leaveDetails.authorities.includes(req.user.email))
      return res.status(200).json({ success: false, message: "You are not an authority to reject this!", result: [] });
    if (leaveDetails.rejected.length !== 0 && leaveDetails.rejected.includes(id.toString()))
      return res.status(200).json({ success: false, message: "You have already rejected this form!", result: [] });
    const rejected = await EmployeeService.rejectThisRequest(leaveDetails._id, id, req.user.email)
    if (!rejected)
      return res.status(200).json({ success: false, message: "Something went wrong while rejecting!", result: [] });
    return res.status(200).json({ success: true, message: "Request Rejected Successfully!", result: [] });
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] });
  }
}

export const revertReject = async (req, res) => {
  try {
    const id = req.user?._id
    if (!id) {
      return res.status(200).json({ success: false, message: "User not found!", result: [] });
    }
    const { leaveId } = req.body
    const leaveDetails = await EmployeeService.getLeaveFormById(leaveId)
    if (!leaveDetails)
      return res.status(200).json({ success: false, message: "Leave Form Not Found!", result: [] });
    if (!leaveDetails.authorities.includes(req.user.email))
      return res.status(200).json({ success: false, message: "You are not an authority to reject this!", result: [] });
    if (!leaveDetails.rejected.map(e => e.toString()).includes(id.toString())) {
      return res.status(200).json({
        success: false,
        message: "You didn't reject this form!",
        result: []
      });
    }

    const rejected = await EmployeeService.revertThisRejection(leaveDetails._id, id)
    if (!rejected)
      return res.status(200).json({ success: false, message: "Something went wrong while rejecting!", result: [] });
    return res.status(200).json({ success: true, message: "Rejection Reverted Successfully!", result: [] });
  }
  catch (err) {
    console.log(err)
    return res.status(200).json({ success: false, message: "Something went wrong!", result: [] });
  }
}

//Work Done:

// 1. Admin Module - Employee, Department CRUD
// 2. Leave Form - API for Appropriate Mail IDs with Default Template

//Pending:

//1. Admin Module - Permission CRUD

//Work Done

//1. Permission Module - Ask, Approve, Reject, Mailings
//2. Role based access - Design, Middleware

//Pending

//1. Test Mailings with Edge Cases