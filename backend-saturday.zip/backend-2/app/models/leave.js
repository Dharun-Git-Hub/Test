import mongoose from "mongoose";

const leaveSchema = new mongoose.Schema({
  subject: { type: String, enum: ["PERMISSION", "LEAVE", "OTHERS"], required: true },
  mailData: { type: String, required: true },
  fromDate: { type: Date, required: true },
  toDate: Date,
  fromTime: Date,
  toTime: Date,
  days: Number,
  approved: { type: Boolean, default: false },
  authorities: [String],
  signed: [String],
  
  rejected: {
    type: [mongoose.Schema.Types.ObjectId],
    ref: "Employee",
    default: []
  }
}, {
  timestamps: true
});

export const Leave = mongoose.model("Leave", leaveSchema);
