import mongoose from 'mongoose';
import validator from 'validator'

const AdminSchema = new mongoose.Schema(
    {
        userName: {
            type: String,
            required: true
        },
        email: {
            type: String,
            validate: {
                validator: validator.isEmail,
                message: 'EMAIL_IS_NOT_VALID'
            },
            lowercase: true,
            unique: true,
            required: true
        },
        password: {
            type: String,
            required: true,
        },
        role: {
            type: String,
            enum: ['subadmin', 'admin'],
            default: 'Admin'
        },
    },
    {
        timestamps: true
    }
)

const Admin = mongoose.model('Admin', AdminSchema);
export default Admin;