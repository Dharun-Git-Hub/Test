import mongoose from "mongoose";

const permissionSchema = new mongoose.Schema(
    {
        authType: {
            type: String,
            required: true,
            enum: ["Administration", "Management", "Leaders", "Employee"]
        },
        read: {
            type: [String],
            enum: ["myleaveform", "employee", "department", "alleaveforms", "permission", "approveleave", "managers", "tls", "mydetails", "pendingleaveform"],
            default: [],
        },
        create: {
            type: [String],
            enum: ["employee", "department", "leave", "permission"],
            default: [],
        },
        update: {
            type: [String],
            enum: ["employee", "department", "leave", "permission", "approveleave", "personal", "rejectleave", "revertleave"],
            default: [],
        },
        delete: {
            type: [String],
            enum: ["employee", "department", "permission"],
            default: [],
        },
    },
    { timestamps: true }
);


export const Permission = mongoose.model("Permission", permissionSchema);