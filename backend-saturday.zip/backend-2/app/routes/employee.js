import express from 'express'
import * as EmployeeControllers from '../controllers/employee.js'
import { authorizeRole } from '../middlewares/authorizeRole.js'
import { requireAuth } from '../middlewares/requireAuth.js'
import * as EmployeeValidators from '../validators/employeeValidator.js'

const router = express.Router()

// router.post('/addEmployee', requireAuth, authorizeRole("Management","Administration"), EmployeeValidators.addEmployeeValidator, EmployeeControllers.addEmployee)
// router.post('/deleteEmployee', requireAuth, authorizeRole("Management","Administration"), EmployeeValidators.deleteEmployeeValidator, EmployeeControllers.deleteEmployee)
// router.post('/updateEmployee', requireAuth, authorizeRole("Management","Administration"), EmployeeValidators.updateEmployeeValidator, EmployeeControllers.updateEmployee)
// router.post('/getAllEmployees', requireAuth, authorizeRole("Management","Administration","Leaders"), EmployeeControllers.getAllEmployees)
// router.post('/editPersonalDetails', requireAuth, authorizeRole("Management","Administration","Leaders","Employee"), EmployeeValidators.editPersonalValidator, EmployeeControllers.editPersonalDetails)
// router.post('/getMyDetails', requireAuth, authorizeRole("Management","Administration","Leaders"), EmployeeControllers.getMyDetails)


// router.post('/managersList', requireAuth, authorizeRole("Management","Administration"), EmployeeControllers.managersList)
// router.post('/tlsList', requireAuth, authorizeRole("Management","Administration"), EmployeeControllers.tlsList)


// router.post('/askForPermission', requireAuth, authorizeRole("Management","Administration","Leaders"), EmployeeValidators.askForPermissionValidator, EmployeeControllers.askForPermission)
// router.post('/getLeaveForms', requireAuth, authorizeRole("Management","Administration"), EmployeeControllers.getLeaveForms)
// router.post('/getPendingRequests', requireAuth, authorizeRole("Management","Administration","Leaders"), EmployeeControllers.getPendingRequests)
// router.post('/getAllPermissionForms',requireAuth,authorizeRole("Management","Administration","Leaders"),EmployeeControllers.getAllPermissionForms)
// router.post('/checkToMonthLeave',requireAuth,authorizeRole("Management","Administration","Leaders","Employee"),EmployeeControllers.checkToMonthLeave)
// router.post('/approvePermission',requireAuth,authorizeRole("Management","Administration","Leaders"),EmployeeControllers.approvePermission)
// router.post('/rejectRequest',requireAuth,authorizeRole("Management","Administration","Leaders"),EmployeeControllers.rejectRequest)
// router.post('/revertReject',requireAuth,authorizeRole("Management","Administration","Leaders"),EmployeeControllers.revertReject)


// router.post('/loginEmployee', EmployeeValidators.loginEmployeeValidator, EmployeeControllers.loginEmployee)
// router.post('/requestChangePassword', EmployeeValidators.requestChangePasswordValidator, EmployeeControllers.requestChangePassword)
// router.post('/changePassword', EmployeeValidators.changePasswordValidator, EmployeeControllers.changePassword)

router.post('/addEmployee', requireAuth, authorizeRole("create","employee"), EmployeeValidators.addEmployeeValidator, EmployeeControllers.addEmployee)
router.post('/deleteEmployee', requireAuth, authorizeRole("delete","employee"), EmployeeValidators.deleteEmployeeValidator, EmployeeControllers.deleteEmployee)
router.post('/updateEmployee', requireAuth, authorizeRole("update","employee"), EmployeeValidators.updateEmployeeValidator, EmployeeControllers.updateEmployee)
router.post('/getAllEmployees', requireAuth, authorizeRole("read","employee"), EmployeeControllers.getAllEmployees)
router.post('/editPersonalDetails', requireAuth, authorizeRole("update","personal"), EmployeeValidators.editPersonalValidator, EmployeeControllers.editPersonalDetails)
router.post('/getMyDetails', requireAuth, authorizeRole("read","mydetails"), EmployeeControllers.getMyDetails)


router.post('/managersList', requireAuth, authorizeRole("read","managers"), EmployeeControllers.managersList)
router.post('/tlsList', requireAuth, authorizeRole("read","tls"), EmployeeControllers.tlsList)


router.post('/askForPermission', requireAuth, authorizeRole("create","leave"), EmployeeValidators.askForPermissionValidator, EmployeeControllers.askForPermission)
router.post('/getLeaveForms', requireAuth, authorizeRole("read","allleaveforms"), EmployeeControllers.getLeaveForms)
router.post('/getPendingRequests', requireAuth, authorizeRole("read","pendingleaveforms"), EmployeeControllers.getPendingRequests)
router.post('/getAllPermissionForms',requireAuth,authorizeRole("read","approveLeave"),EmployeeControllers.getAllPermissionForms)
router.post('/checkToMonthLeave',requireAuth,authorizeRole("create","leave"),EmployeeControllers.checkToMonthLeave)
router.post('/approvePermission',requireAuth,authorizeRole("update","approveleave"),EmployeeControllers.approvePermission)
router.post('/rejectRequest',requireAuth,authorizeRole("update","approveleave"),EmployeeControllers.rejectRequest)
router.post('/revertReject',requireAuth,authorizeRole("update","approveleave"),EmployeeControllers.revertReject)


router.post('/loginEmployee', EmployeeValidators.loginEmployeeValidator, EmployeeControllers.loginEmployee)
router.post('/requestChangePassword', EmployeeValidators.requestChangePasswordValidator, EmployeeControllers.requestChangePassword)
router.post('/changePassword', EmployeeValidators.changePasswordValidator, EmployeeControllers.changePassword)


export default router