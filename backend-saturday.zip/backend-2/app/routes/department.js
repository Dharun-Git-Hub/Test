import express from 'express'
import * as DepartmentControllers from '../controllers/department.js'
import { requireAuth } from '../middlewares/requireAuth.js'
import { authorizeRole } from '../middlewares/authorizeRole.js'
import * as DepartmentValidators from '../validators/departmentValidator.js'

const router = express.Router()

router.post('/addDepartment', requireAuth, authorizeRole("create","department"), DepartmentValidators.createDepartmentValidator, DepartmentControllers.createDepartment)
router.post('/updateDepartment', requireAuth, authorizeRole("update","department"), DepartmentValidators.updateDepartmentValidator, DepartmentControllers.updateDepartment)
router.post('/deleteDepartment', requireAuth, authorizeRole("delete", "department"), DepartmentValidators.deleteDepartmentValidator, DepartmentControllers.deleteDepartment)
router.post('/getAllDepartments', requireAuth, authorizeRole("delete", "department"), DepartmentControllers.getAllDepartments)

export default router