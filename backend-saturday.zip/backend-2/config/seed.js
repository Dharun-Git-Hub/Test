import { Permission } from "../app/models/permission.js"

const defaultPermissions = [
    {
        authType: "Employee",
        read: ["myleaveform", "mydetails"],
        create: ["leave"],
        update: ["personal"],
        delete: []
    },
    {
        authType: "Management",
        read: ["myleaveform", "employee", "department", "alleaveforms", "permission", "approveleave", "managers", "tls", "mydetails", "pendingleaveform"],
        create: ["employee", "department", "leave", "permission"],
        update: ["employee", "department", "leave", "permission", "approveleave", "personal", "rejectleave", "revertleave"],
        delete: ["employee", "department", "permission"]
    },
    {
        authType: "Administration",
        read: ["employee", "department", "alleaveforms", "approveleave", "managers", "tls", "mydetails", "pendingleaveform"],
        create: ["employee", "department", "leave"],
        update: ["employee", "department", "leave", "personal", "approveleave", "rejectleave", "revertleave"],
        delete: ["employee","department"]
    },
    {
        authType: "Leaders",
        read: ["employee", "myleaveform", "mydetails"],
        create: ["leave"],
        update: ["employee", "personal"],
        delete: []
    }
]

export const seedPermissions = async () => {
    try{
        const count = await Permission.countDocuments()
        if(count!==0)
            return
        for(const type of defaultPermissions){
            await Permission.create({
                authType:type.authType,
                read: type.read,
                update: type.update,
                create: type.create,
                delete: type.delete
            })
        }
    }
    catch(err){
        console.log(err)
        throw err
    }
}